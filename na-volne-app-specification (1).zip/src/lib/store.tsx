"use client";

import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import {
  PLAN_LIBRARY,
  scoreAnswers,
  type LeaderKey,
  type TestResult,
} from "./data";

// ───────────────────────────── Типы ─────────────────────────────

export type FlowRoute =
  | "splash"
  | "onboarding"
  | "auth"
  | "verify"
  | "testCover"
  | "testQ"
  | "testResult"
  | "plan";

export type AppRoute =
  | "today"
  | "tools"
  | "map"
  | "courses"
  | "course"
  | "lesson"
  | "techniques"
  | "technique"
  | "soundscapes"
  | "player"
  | "body"
  | "diary"
  | "sleep"
  | "community"
  | "profile"
  | "settings";

export type SosRoute = "sos" | "sosBreathe" | "sosDialog" | "sosGrounding";
export type TabId = "today" | "tools" | "community" | "profile";

export interface Entry<T extends string = string> {
  route: T;
  params?: Record<string, string>;
}

export interface CheckIn {
  day: string;
  mood: number;
  note?: string;
  sleep?: number;
  energy?: number;
}

export interface DiaryEntry {
  id: string;
  day: string;
  situation: string;
  thought: string;
  emotion: number;
  support: string;
  against: string;
  balanced: string;
  faithBefore: number;
  faithAfter: number;
}

export interface Post {
  id: string;
  nick: string;
  text: string;
  hearts: number;
  time: string;
  mine?: boolean;
  liked?: boolean;
}

export interface GratitudeEntry {
  day: string;
  items: string[];
}

export interface AppState {
  uid: string;
  onboarded: boolean;
  user: { name: string; contact: string; isGuest: boolean } | null;
  premium: boolean;
  premiumPlan: "month" | "year" | null;
  planValue: string | null;
  testDraft: number[];
  result: TestResult | null;
  checkins: CheckIn[];
  planDone: Record<string, boolean[]>;
  doneTechniques: Record<string, string[]>;
  completedLessons: Record<string, string[]>;
  gratitudes: GratitudeEntry[];
  diary: DiaryEntry[];
  myPosts: Post[];
  likedPosts: string[];
  settings: { push: boolean; remindTime: string; days: number[]; sounds: boolean };
}

const LS_KEY = "navolne_state";

function uid(): string {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) return crypto.randomUUID();
  return `u_${Math.random().toString(36).slice(2)}${Date.now().toString(36)}`;
}

function defaultState(): AppState {
  return {
    uid: uid(),
    onboarded: false,
    user: null,
    premium: false,
    premiumPlan: null,
    planValue: null,
    testDraft: [],
    result: null,
    checkins: [],
    planDone: {},
    doneTechniques: {},
    completedLessons: {},
    gratitudes: [],
    diary: [],
    myPosts: [],
    likedPosts: [],
    settings: { push: true, remindTime: "20:00", days: [0, 1, 2, 3, 4, 5, 6], sounds: true },
  };
}

// ───────────────────────────── Контекст ─────────────────────────────

export interface ToastItem {
  id: number;
  msg: string;
}

interface AppCtx {
  hydrated: boolean;
  state: AppState;
  update: (patch: Partial<AppState>) => void;
  resetAll: () => void;

  flow: Entry<FlowRoute>[];
  flowCurrent: Entry<FlowRoute>;
  flowGo: (route: FlowRoute) => void;
  flowBack: () => void;
  flowReplace: (route: FlowRoute) => void;
  flowReset: (route: FlowRoute) => void;

  tab: TabId;
  stacks: Record<TabId, Entry<AppRoute>[]>;
  current: Entry<AppRoute>;
  go: (route: AppRoute, params?: Record<string, string>) => void;
  back: () => void;
  goTab: (t: TabId) => void;

  sos: Entry<SosRoute>[] | null;
  sosCurrent: Entry<SosRoute> | null;
  openSos: () => void;
  closeSos: () => void;
  sosGo: (r: SosRoute) => void;
  sosBack: () => void;

  paywall: { open: boolean; source: string | null };
  openPaywall: (source?: string) => void;
  closePaywall: () => void;
  requirePremium: (source: string, cb: () => void) => void;

  checkinOpen: boolean;
  openCheckin: () => void;
  closeCheckin: () => void;

  toasts: ToastItem[];
  toast: (msg: string) => void;

  todayKey: string;
  todayCheckin: CheckIn | null;
  streak: number;
  leaderKey: LeaderKey;
  planSteps: string[];

  startTest: () => void;
  answerQuestion: (v: number) => void;
  backQuestion: () => void;

  saveCheckin: (mood: number, note: string, sleep: number | null, energy: number | null) => void;
  togglePlanStep: (i: number) => void;
  completeTechnique: (id: string) => void;
  completeLesson: (courseId: string, lessonId: string) => void;
  addDiary: (e: Omit<DiaryEntry, "id" | "day">) => void;
  addGratitude: (items: string[]) => void;
  addPost: (text: string) => void;
  toggleHeart: (id: string) => void;

  chartWeek: { day: string; label: string; mood: number | null; sleep: number | null; real: boolean }[];
  techniquesDoneToday: number;
}

const Ctx = createContext<AppCtx | null>(null);

export function useApp(): AppCtx {
  const v = useContext(Ctx);
  if (!v) throw new Error("useApp outside provider");
  return v;
}

const WEEK_LABELS = ["Вс", "Пн", "Вт", "Ср", "Чт", "Пт", "Сб"];

// детерминированный «демо-фон» графика для дней без реальных чек-инов
function seedFor(day: string): { mood: number; sleep: number } {
  let h = 0;
  for (let i = 0; i < day.length; i++) h = (h * 31 + day.charCodeAt(i)) % 9973;
  return { mood: 2 + (h % 3), sleep: 5 + (h % 4) };
}

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [hydrated, setHydrated] = useState(false);
  const [state, setState] = useState<AppState>(() => defaultState());

  const [flow, setFlow] = useState<Entry<FlowRoute>[]>([{ route: "splash" }]);
  const [tab, setTab] = useState<TabId>("today");
  const [stacks, setStacks] = useState<Record<TabId, Entry<AppRoute>[]>>({
    today: [{ route: "today" }],
    tools: [{ route: "tools" }],
    community: [{ route: "community" }],
    profile: [{ route: "profile" }],
  });
  const [sos, setSos] = useState<Entry<SosRoute>[] | null>(null);
  const [paywall, setPaywall] = useState<{ open: boolean; source: string | null }>({
    open: false,
    source: null,
  });
  const [checkinOpen, setCheckinOpen] = useState(false);
  const [toasts, setToasts] = useState<ToastItem[]>([]);

  // ── загрузка состояния (только на клиенте, чтобы избежать рассинхрона SSR) ──
  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(LS_KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as Partial<AppState>;
        setState({ ...defaultState(), ...parsed, settings: { ...defaultState().settings, ...(parsed.settings ?? {}) } });
      }
    } catch {
      /* localStorage недоступен — работаем в памяти */
    }
    setHydrated(true);
  }, []);

  // ── сохранение ──
  useEffect(() => {
    if (!hydrated) return;
    try {
      window.localStorage.setItem(LS_KEY, JSON.stringify(state));
      // зеркала по требованию ТЗ (ключи navolne_*)
      window.localStorage.setItem("navolne_premium", state.premium ? "1" : "0");
      window.localStorage.setItem("navolne_word", state.result?.word ?? "");
      window.localStorage.setItem("navolne_uid", state.uid);
    } catch {
      /* ignore */
    }
  }, [hydrated, state]);

  // ── синхронизация с сервером (офлайн-толерантно) ──
  const syncPayload = useMemo(
    () => ({
      uid: state.uid,
      user: state.user,
      premium: state.premium,
      premiumPlan: state.premiumPlan,
      result: state.result,
      checkins: state.checkins,
    }),
    [state.uid, state.user, state.premium, state.premiumPlan, state.result, state.checkins]
  );
  useEffect(() => {
    if (!hydrated) return;
    if (!syncPayload.result && syncPayload.checkins.length === 0 && !syncPayload.user) return;
    const t = setTimeout(() => {
      fetch("/api/sync", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(syncPayload),
      }).catch(() => {});
    }, 900);
    return () => clearTimeout(t);
  }, [hydrated, syncPayload]);

  // ── история браузера ──
  const pushHist = useCallback((tag: string) => {
    try {
      window.history.pushState({ navolne: 1 }, "", `#${tag}`);
    } catch {
      /* ignore */
    }
  }, []);

  const update = useCallback((patch: Partial<AppState>) => {
    setState((s) => ({ ...s, ...patch }));
  }, []);

  const toast = useCallback((msg: string) => {
    const id = Date.now() + Math.random();
    setToasts((ts) => [...ts.slice(-2), { id, msg }]);
    setTimeout(() => setToasts((ts) => ts.filter((t) => t.id !== id)), 2800);
  }, []);

  // ── поток введения ──
  const flowGo = useCallback((route: FlowRoute) => {
    setFlow((f) => [...f, { route }]);
    pushHist(route);
  }, [pushHist]);
  const flowBack = useCallback(() => {
    setFlow((f) => (f.length > 1 ? f.slice(0, -1) : f));
  }, []);
  const flowReplace = useCallback((route: FlowRoute) => {
    setFlow((f) => [...f.slice(0, -1), { route }]);
    pushHist(route);
  }, [pushHist]);
  const flowReset = useCallback((route: FlowRoute) => {
    setFlow([{ route }]);
    pushHist(route);
  }, [pushHist]);

  // ── навигация приложения ──
  const tabRef = useRef<TabId>("today");
  tabRef.current = tab;

  const goReal = useCallback((route: AppRoute, params?: Record<string, string>) => {
    const t = tabRef.current;
    setStacks((st) => ({ ...st, [t]: [...st[t], { route, params }] }));
    pushHist(route);
  }, [pushHist]);

  const back = useCallback(() => {
    const t = tabRef.current;
    setStacks((st) => (st[t].length > 1 ? { ...st, [t]: st[t].slice(0, -1) } : st));
  }, []);

  const goTab = useCallback((t: TabId) => {
    setTab(t);
    pushHist(t);
  }, [pushHist]);

  // ── SOS поверх всего ──
  const openSos = useCallback(() => {
    setSos([{ route: "sos" }]);
    pushHist("sos");
  }, [pushHist]);
  const closeSos = useCallback(() => setSos(null), []);
  const sosGo = useCallback((r: SosRoute) => {
    setSos((s) => (s ? [...s, { route: r }] : s));
    pushHist(r);
  }, [pushHist]);
  const sosBack = useCallback(() => {
    setSos((s) => (s && s.length > 1 ? s.slice(0, -1) : null));
  }, []);

  const openPaywall = useCallback((source?: string) => {
    setPaywall({ open: true, source: source ?? null });
    pushHist("paywall");
  }, [pushHist]);
  const closePaywall = useCallback(() => setPaywall({ open: false, source: null }), []);

  const openCheckin = useCallback(() => setCheckinOpen(true), []);
  const closeCheckin = useCallback(() => setCheckinOpen(false), []);

  const requirePremium = useCallback(
    (source: string, cb: () => void) => {
      if (state.premium) cb();
      else openPaywall(source);
    },
    [state.premium, openPaywall]
  );

  // глобальная обработка системной «Назад»
  const backHandler = useRef<() => void>(() => {});
  backHandler.current = () => {
    if (checkinOpen) return setCheckinOpen(false);
    if (paywall.open) return setPaywall({ open: false, source: null });
    if (sos) return sosBack();
    if (!state.onboarded) {
      if (flow.length > 1) return setFlow((f) => f.slice(0, -1));
      return pushHist("splash");
    }
    const st = stacks[tab];
    if (st.length > 1) back();
    else pushHist(tab);
  };
  useEffect(() => {
    const onPop = () => backHandler.current();
    window.addEventListener("popstate", onPop);
    try {
      window.history.replaceState({ navolne: 0 }, "", "#app");
    } catch {
      /* ignore */
    }
    return () => window.removeEventListener("popstate", onPop);
  }, [pushHist]);

  // ── доменные действия ──

  const todayKey = useMemo(() => {
    const d = new Date();
    return `${d.getFullYear()}-${`${d.getMonth() + 1}`.padStart(2, "0")}-${`${d.getDate()}`.padStart(2, "0")}`;
  }, [hydrated]);

  const startTest = useCallback(() => {
    // повторное прохождение: чистый тест в intro-потоке; «Начать день 1» вернёт в приложение
    update({ testDraft: [], onboarded: false });
    setFlow([{ route: "testCover" }]);
  }, [update]);

  const answerQuestion = useCallback(
    (v: number) => {
      const draft = [...state.testDraft, v];
      if (draft.length < 14) {
        update({ testDraft: draft });
      } else {
        const result = scoreAnswers(draft);
        update({ testDraft: [], result });
        flowReplace("testResult");
      }
    },
    [state.testDraft, update, flowReplace]
  );

  const backQuestion = useCallback(() => {
    if (state.testDraft.length > 0) update({ testDraft: state.testDraft.slice(0, -1) });
    else flowBack();
  }, [state.testDraft, update, flowBack]);

  const saveCheckin = useCallback(
    (mood: number, note: string, sleep: number | null, energy: number | null) => {
      const entry: CheckIn = {
        day: todayKey,
        mood,
        note: note.trim() ? note.trim() : undefined,
        sleep: sleep ?? undefined,
        energy: energy ?? undefined,
      };
      const rest = state.checkins.filter((c) => c.day !== todayKey);
      update({ checkins: [...rest, entry] });
    },
    [state.checkins, todayKey, update]
  );

  const todayCheckin = useMemo(
    () => state.checkins.find((c) => c.day === todayKey) ?? null,
    [state.checkins, todayKey]
  );

  const streak = useMemo(() => {
    const days = new Set(state.checkins.map((c) => c.day));
    let count = 0;
    const d = new Date();
    if (!days.has(todayKey)) d.setDate(d.getDate() - 1); // сегодня ещё можно успеть
    for (let i = 0; i < 365; i++) {
      const key = `${d.getFullYear()}-${`${d.getMonth() + 1}`.padStart(2, "0")}-${`${d.getDate()}`.padStart(2, "0")}`;
      if (days.has(key)) count++;
      else break;
      d.setDate(d.getDate() - 1);
    }
    return count;
  }, [state.checkins, todayKey]);

  const leaderKey: LeaderKey = useMemo(() => {
    if (!state.result || !state.result.leader) return "norm";
    return state.result.leader;
  }, [state.result]);

  const planSteps = useMemo(() => PLAN_LIBRARY[leaderKey].steps, [leaderKey]);

  const togglePlanStep = useCallback(
    (i: number) => {
      const cur = state.planDone[todayKey] ?? planSteps.map(() => false);
      const next = [...cur];
      next[i] = !next[i];
      update({ planDone: { ...state.planDone, [todayKey]: next } });
    },
    [state.planDone, todayKey, planSteps, update]
  );

  const completeTechnique = useCallback(
    (id: string) => {
      const cur = state.doneTechniques[todayKey] ?? [];
      if (!cur.includes(id)) {
        update({ doneTechniques: { ...state.doneTechniques, [todayKey]: [...cur, id] } });
      }
    },
    [state.doneTechniques, todayKey, update]
  );

  const completeLesson = useCallback(
    (courseId: string, lessonId: string) => {
      const cur = state.completedLessons[courseId] ?? [];
      if (!cur.includes(lessonId)) {
        update({ completedLessons: { ...state.completedLessons, [courseId]: [...cur, lessonId] } });
      } else {
        update({ completedLessons: { ...state.completedLessons, [courseId]: cur.filter((l) => l !== lessonId) } });
      }
    },
    [state.completedLessons, update]
  );

  const addDiary = useCallback(
    (e: Omit<DiaryEntry, "id" | "day">) => {
      update({ diary: [{ ...e, id: uid(), day: todayKey }, ...state.diary].slice(0, 60) });
    },
    [state.diary, todayKey, update]
  );

  const addGratitude = useCallback(
    (items: string[]) => {
      const rest = state.gratitudes.filter((g) => g.day !== todayKey);
      update({ gratitudes: [{ day: todayKey, items }, ...rest].slice(0, 90) });
    },
    [state.gratitudes, todayKey, update]
  );

  const addPost = useCallback(
    (text: string) => {
      const post: Post = { id: uid(), nick: "Моя волна", text: text.trim(), hearts: 0, time: "сейчас", mine: true };
      update({ myPosts: [post, ...state.myPosts] });
    },
    [state.myPosts, update]
  );

  const toggleHeart = useCallback(
    (id: string) => {
      const liked = state.likedPosts.includes(id);
      update({ likedPosts: liked ? state.likedPosts.filter((p) => p !== id) : [...state.likedPosts, id] });
    },
    [state.likedPosts, update]
  );

  const chartWeek = useMemo(() => {
    const out: AppCtx["chartWeek"] = [];
    const byDay = new Map(state.checkins.map((c) => [c.day, c]));
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const key = `${d.getFullYear()}-${`${d.getMonth() + 1}`.padStart(2, "0")}-${`${d.getDate()}`.padStart(2, "0")}`;
      const real = byDay.get(key);
      const seed = seedFor(key);
      out.push({
        day: key,
        label: WEEK_LABELS[d.getDay()],
        mood: real ? real.mood : i === 0 ? null : seed.mood,
        sleep: real?.sleep ?? (i === 0 ? null : seed.sleep),
        real: Boolean(real),
      });
    }
    return out;
  }, [state.checkins]);

  const techniquesDoneToday = (state.doneTechniques[todayKey] ?? []).length;

  const resetAll = useCallback(() => {
    try {
      Object.keys(window.localStorage)
        .filter((k) => k.startsWith("navolne"))
        .forEach((k) => window.localStorage.removeItem(k));
    } catch {
      /* ignore */
    }
    window.location.reload();
  }, []);

  const value: AppCtx = {
    hydrated,
    state,
    update,
    resetAll,
    flow,
    flowCurrent: flow[flow.length - 1],
    flowGo,
    flowBack,
    flowReplace,
    flowReset,
    tab,
    stacks,
    current: stacks[tab][stacks[tab].length - 1],
    go: goReal,
    back,
    goTab,
    sos,
    sosCurrent: sos ? sos[sos.length - 1] : null,
    openSos,
    closeSos,
    sosGo,
    sosBack,
    paywall,
    openPaywall,
    closePaywall,
    requirePremium,
    checkinOpen,
    openCheckin,
    closeCheckin,
    toasts,
    toast,
    todayKey,
    todayCheckin,
    streak,
    leaderKey,
    planSteps,
    startTest,
    answerQuestion,
    backQuestion,
    saveCheckin,
    togglePlanStep,
    completeTechnique,
    completeLesson,
    addDiary,
    addGratitude,
    addPost,
    toggleHeart,
    chartWeek,
    techniquesDoneToday,
  };

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}
