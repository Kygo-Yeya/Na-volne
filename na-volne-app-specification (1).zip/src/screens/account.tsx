"use client";

import React, { useMemo, useState } from "react";
import {
  ArrowRight,
  BellRing,
  Crown,
  Download,
  Heart,
  Leaf,
  RefreshCw,
  RotateCcw,
  Settings2,
  ShieldCheck,
  Trash2,
  TriangleAlert,
  Users,
  Waves,
  X,
  Zap,
} from "lucide-react";
import { COMMUNITY_SEED, WEEKDAYS_SHORT, plural } from "@/lib/data";
import { useApp } from "@/lib/store";
import { Btn, Card, CardSkeleton, EmptyState, ErrorState, Modal, Sheet, SuccessMark, TopBar, useFakeLoad } from "@/components/ui";

// ───────────────────────── Профиль ─────────────────────────

export function Profile() {
  const { state, streak, go, openPaywall, startTest, techniquesDoneToday, toast, resetAll } = useApp();
  const loading = useFakeLoad(400);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const name = state.user?.name ?? "Гость";

  const exportData = () => {
    const payload = {
      exportedAt: new Date().toISOString(),
      app: "navolne",
      state,
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "navolne-data.json";
    a.click();
    URL.revokeObjectURL(url);
    toast("Экспорт сохранён в файл");
  };

  const stats = [
    { label: `${streak} ${plural(streak, ["день", "дня", "дней"])} подряд`, icon: Zap, grad: "linear-gradient(140deg,#fcd34d,#e07a5f)" },
    { label: `${state.checkins.length} ${plural(state.checkins.length, ["чек-ин", "чек-ина", "чек-инов"])}`, icon: Heart, grad: "linear-gradient(140deg,#f9a8d4,#e07a5f)" },
    { label: `${state.diary.length} ${plural(state.diary.length, ["запись", "записи", "записей"])} в дневнике`, icon: Waves, grad: "linear-gradient(140deg,#67e8f9,#0e7490)" },
    {
      label: state.result ? `Устойчивость ${state.result.resilienceIndex}/100` : "Пройди тест для метрик",
      icon: ShieldCheck,
      grad: "linear-gradient(140deg,#5eead4,#0f766e)",
    },
  ];

  return (
    <div className="screen">
      <div className="screen-pad" style={{ paddingTop: 66 }}>
        {loading ? (
          <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
            <CardSkeleton lines={2} />
            <CardSkeleton lines={4} />
            <CardSkeleton lines={3} />
          </div>
        ) : (
          <div className="anim-in" style={{ display: "flex", flexDirection: "column", gap: 14 }}>
            {/* шапка профиля */}
            <div className="row" style={{ gap: 14 }}>
              <div
                style={{
                  width: 64,
                  height: 64,
                  borderRadius: 22,
                  display: "grid",
                  placeItems: "center",
                  background: "linear-gradient(140deg,#22d3ee,#0e7490)",
                  color: "#fff",
                  fontSize: 26,
                  fontWeight: 800,
                  boxShadow: "0 14px 28px -12px rgba(14,116,144,0.6)",
                }}
              >
                {name.charAt(0).toUpperCase()}
              </div>
              <div>
                <h1 className="h-2">{name}</h1>
                <p className="small">
                  {state.user?.isGuest ? "Гостевой режим • данные на устройстве" : state.user?.contact || "аккаунт активен"}
                </p>
              </div>
            </div>

            {/* статистика */}
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
              {stats.map((s) => (
                <Card key={s.label} style={{ padding: 14 }}>
                  <div className="icon-tile" style={{ width: 34, height: 34, borderRadius: 11, background: s.grad, marginBottom: 8 }}>
                    <s.icon size={17} />
                  </div>
                  <p className="body-t" style={{ fontSize: 13.5, fontWeight: 650 }}>{s.label}</p>
                  {s.label.includes("сегодня") === false && techniquesDoneToday > 0 && s.icon === Waves ? null : null}
                </Card>
              ))}
            </div>

            {/* премиум */}
            {state.premium ? (
              <Card style={{ background: "linear-gradient(135deg,#3b2f12,#7c5b12)", color: "#fef3c7", border: "none" }}>
                <div className="row">
                  <Crown size={22} color="#fcd34d" />
                  <div style={{ flex: 1 }}>
                    <h3 className="h-3" style={{ color: "#fde68a" }}>Premium активен</h3>
                    <p style={{ margin: 0, fontSize: 12.5, color: "rgba(254,243,199,0.75)" }}>
                      Тариф «{state.premiumPlan === "year" ? "Год" : "Месяц"}» • карта, курсы и аудио без лимита
                    </p>
                  </div>
                </div>
              </Card>
            ) : (
              <Card pressable onClick={() => openPaywall("profile")} style={{ background: "linear-gradient(135deg,#0b3f52,#0e7490)", color: "#eafafe", border: "none" }}>
                <div className="between">
                  <div className="row">
                    <Crown size={22} color="#fcd34d" />
                    <div>
                      <h3 className="h-3" style={{ color: "#fff" }}>Попробовать Premium</h3>
                      <p style={{ margin: "2px 0 0", fontSize: 13, color: "rgba(234,250,254,0.78)" }}>7 дней бесплатно • отмена в любой момент</p>
                    </div>
                  </div>
                  <ArrowRight size={18} color="#67e8f9" />
                </div>
              </Card>
            )}

            {/* меню */}
            <Card style={{ padding: "6px 16px" }}>
              {[
                { icon: Settings2, label: "Настройки и напоминания", fn: () => go("settings") },
                { icon: RotateCcw, label: "Пройти тест заново", fn: startTest },
                { icon: Download, label: "Экспорт моих данных", fn: exportData },
                { icon: Trash2, label: "Удалить аккаунт", fn: () => setConfirmDelete(true), danger: true },
              ].map((m, i, arr) => (
                <button
                  key={m.label}
                  onClick={m.fn}
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: 12,
                    width: "100%",
                    minHeight: 52,
                    background: "none",
                    border: "none",
                    borderBottom: i === arr.length - 1 ? "none" : "1px solid rgba(13,36,48,0.07)",
                    fontSize: 15,
                    fontWeight: 600,
                    color: m.danger ? "#dc2626" : "#0d2430",
                    cursor: "pointer",
                    textAlign: "left",
                    padding: 0,
                  }}
                >
                  <m.icon size={18} color={m.danger ? "#dc2626" : "#0e7490"} />
                  {m.label}
                  <ArrowRight size={15} style={{ marginLeft: "auto", opacity: 0.4 }} />
                </button>
              ))}
            </Card>

            <p className="tiny" style={{ textAlign: "center", padding: "0 12px" }}>
              «На волне» — инструмент самопомощи и не заменяет помощь специалиста. Если тяжело долго — обратись к
              психологу или на телефон доверия.
            </p>
          </div>
        )}

        <Modal open={confirmDelete} onClose={() => setConfirmDelete(false)}>
          <div
            style={{
              width: 60,
              height: 60,
              margin: "0 auto 12px",
              borderRadius: 20,
              display: "grid",
              placeItems: "center",
              background: "rgba(249,115,115,0.14)",
              color: "#dc2626",
            }}
          >
            <TriangleAlert size={28} />
          </div>
          <h3 className="h-3" style={{ marginBottom: 8 }}>Удалить аккаунт и все данные?</h3>
          <p className="small" style={{ marginBottom: 18 }}>
            Тест, чек-ины и записи дневника будут стёрты без возможности восстановления.
          </p>
          <Btn full variant="danger" onClick={resetAll}>Удалить навсегда</Btn>
          <Btn full variant="ghost" onClick={() => setConfirmDelete(false)}>Оставить всё как есть</Btn>
        </Modal>
      </div>
    </div>
  );
}

// ───────────────────────── Настройки ─────────────────────────

function Toggle({ on, onClick, label }: { on: boolean; onClick: () => void; label: string }) {
  return <button className={`switch ${on ? "on" : ""}`} onClick={onClick} role="switch" aria-checked={on} aria-label={label} />;
}

export function Settings() {
  const { back, state, update, toast, openPaywall } = useApp();
  const s = state.settings;

  const setS = (patch: Partial<typeof s>) => update({ settings: { ...s, ...patch } });

  const toggleDay = (i: number) => {
    const days = s.days.includes(i) ? s.days.filter((d) => d !== i) : [...s.days, i].sort();
    setS({ days });
  };

  const testPush = () => {
    toast("Тестовое напоминание придёт через 4 секунды");
    setTimeout(() => toast("Напоминание «На волне»: отметь настроение дня"), 4000);
  };

  return (
    <div className="screen">
      <TopBar title="Настройки" onBack={back} />
      <div className="screen-pad" style={{ paddingTop: 6, display: "flex", flexDirection: "column", gap: 14 }}>
        <Card>
          <div className="between" style={{ marginBottom: 12 }}>
            <div className="row">
              <div className="icon-tile" style={{ width: 38, height: 38, borderRadius: 12, background: "linear-gradient(140deg,#67e8f9,#0e7490)" }}>
                <BellRing size={18} />
              </div>
              <div>
                <h3 className="h-3">Напоминания</h3>
                <p className="tiny">Пуш-планировщик (имитация в макете)</p>
              </div>
            </div>
            <Toggle on={s.push} onClick={() => setS({ push: !s.push })} label="Включить напоминания" />
          </div>

          {s.push && (
            <div className="anim-in">
              <label className="label" htmlFor="rem-time">Время вечернего напоминания</label>
              <input
                id="rem-time"
                type="time"
                className="input"
                value={s.remindTime}
                onChange={(e) => setS({ remindTime: e.target.value })}
                style={{ marginBottom: 12 }}
              />
              <p className="label">Дни недели</p>
              <div className="row" style={{ gap: 6, flexWrap: "wrap", marginBottom: 14 }}>
                {WEEKDAYS_SHORT.map((d, i) => (
                  <button
                    key={d}
                    className={`chip ${s.days.includes(i) ? "active" : ""}`}
                    style={{ minHeight: 36, padding: "0 12px" }}
                    onClick={() => toggleDay(i)}
                  >
                    {d}
                  </button>
                ))}
              </div>
              <Btn variant="soft" size="sm" onClick={testPush}>Отправить тестовое напоминание</Btn>
            </div>
          )}
        </Card>

        <Card>
          <div className="between">
            <div>
              <h3 className="h-3">Звук в практиках</h3>
              <p className="tiny">Мягкие сигналы в дыхании и таймерах</p>
            </div>
            <Toggle on={s.sounds} onClick={() => setS({ sounds: !s.sounds })} label="Звук в практиках" />
          </div>
        </Card>

        <Card pressable onClick={() => openPaywall("settings")}>
          <div className="between">
            <div className="row">
              <Crown size={20} color={state.premium ? "#b45309" : "#64798a"} />
              <div>
                <h3 className="h-3">Подписка</h3>
                <p className="small">{state.premium ? `Premium • тариф «${state.premiumPlan === "year" ? "Год" : "Месяц"}»` : "Free • Premium со всеми курсами"}</p>
              </div>
            </div>
            <ArrowRight size={17} color="#64798a" />
          </div>
        </Card>

        <Card>
          <div className="row" style={{ gap: 10, marginBottom: 10 }}>
            <ShieldCheck size={20} color="#0e7490" />
            <h3 className="h-3">Данные и конфиденциальность</h3>
          </div>
          <p className="small" style={{ marginBottom: 10 }}>
            Обработка данных — по 152-ФЗ. Ответы тестов и записи хранятся на устройстве и синхронизируются в
            зашифрованном виде; в рекламном таргетинге не используются. Удаление — в один тап в профиле.
          </p>
          <div className="notice">
            <Leaf size={15} style={{ flexShrink: 0, marginTop: 1, color: "#0e7490" }} />
            <span>По умолчанию собираем минимум: никаких точных геолокаций и контактов «на всякий случай».</span>
          </div>
        </Card>

        <p className="tiny" style={{ textAlign: "center" }}>«На волне» • версия 1.0 (интерактивный макет)</p>
      </div>
    </div>
  );
}

// ───────────────────────── Paywall ─────────────────────────

type PayPhase = "idle" | "processing" | "done";

export function Paywall() {
  const { paywall, closePaywall, update, toast } = useApp();
  const [plan, setPlan] = useState<"month" | "year">("year");
  const [trial, setTrial] = useState(true);
  const [phase, setPhase] = useState<PayPhase>("idle");

  if (!paywall.open) return null;

  const features = [
    "Карта личности с обновлением по данным",
    "Все мини-курсы и 12 техник",
    "Саундскейпы без лимита времени",
    "Детальная аналитика паттернов на 30 дней",
  ];

  const pay = () => {
    setPhase("processing");
    setTimeout(() => {
      setPhase("done");
      setTimeout(() => {
        update({ premium: true, premiumPlan: plan });
        closePaywall();
        setPhase("idle");
        toast("Premium активирован. Карта личности обновлена");
      }, 1300);
    }, 1700);
  };

  const priceMain = plan === "year" ? "2 990 ₽/год" : "399 ₽/мес";

  return (
    <div className="overlay-page" style={{ background: "#f2f7f9", zIndex: 96 }}>
      <div
        style={{
          background: "linear-gradient(160deg,#7c5b12 0%, #b45309 60%, #e07a5f 100%)",
          borderRadius: "0 0 34px 34px",
          padding: "66px 22px 26px",
          color: "#fff8e7",
          position: "relative",
          overflow: "hidden",
        }}
      >
        <button
          onClick={closePaywall}
          aria-label="Закрыть"
          className="back-btn on-dark"
          style={{ position: "absolute", top: 58, right: 18, width: 40, height: 40 }}
        >
          <X size={18} />
        </button>
        <div
          style={{
            width: 62,
            height: 62,
            borderRadius: 20,
            display: "grid",
            placeItems: "center",
            background: "rgba(255,255,255,0.16)",
            marginBottom: 14,
            animation: "popIn .5s var(--ease-out) both .1s",
          }}
        >
          <Crown size={30} color="#fde68a" />
        </div>
        <h1 className="h-1" style={{ color: "#fff8e7" }}>На волне Premium</h1>
        <p style={{ margin: "8px 0 0", fontSize: 14.5, color: "rgba(255,248,231,0.82)", lineHeight: 1.5 }}>
          Глубже в самопознании: полная картина, все практики и звук без границ.
        </p>
      </div>

      <div style={{ padding: "18px 20px 40px" }}>
        <Card style={{ marginBottom: 14 }}>
          {features.map((f) => (
            <div key={f} className="row" style={{ padding: "9px 0", borderBottom: "1px solid rgba(13,36,48,0.06)", gap: 10 }}>
              <span style={{ width: 24, height: 24, borderRadius: 9, background: "rgba(252,211,77,0.18)", color: "#b45309", display: "grid", placeItems: "center", flexShrink: 0 }}>
                <Crown size={13} />
              </span>
              <span className="body-t" style={{ fontSize: 14.5 }}>{f}</span>
            </div>
          ))}
        </Card>

        <div style={{ display: "flex", flexDirection: "column", gap: 10, marginBottom: 14 }}>
          <button className={`tariff ${plan === "year" ? "active" : ""}`} onClick={() => setPlan("year")}>
            <span className="between">
              <span>
                <b style={{ fontSize: 16 }}>Год</b>
                <span className="tiny" style={{ display: "block", marginTop: 2 }}>≈ 249 ₽/мес</span>
              </span>
              <span style={{ textAlign: "right" }}>
                <b style={{ fontSize: 18 }}>2 990 ₽</b>
                <span className="lock-badge" style={{ display: "inline-flex", marginLeft: 8, background: "rgba(16,185,129,0.14)", color: "#0e9f6e", textTransform: "none", fontSize: 11 }}>
                  выгоднее
                </span>
              </span>
            </span>
          </button>
          <button className={`tariff ${plan === "month" ? "active" : ""}`} onClick={() => setPlan("month")}>
            <span className="between">
              <b style={{ fontSize: 16 }}>Месяц</b>
              <b style={{ fontSize: 18 }}>399 ₽</b>
            </span>
          </button>
        </div>

        <button
          className="row"
          onClick={() => setTrial(!trial)}
          style={{ background: "none", border: "none", padding: "2px 2px 12px", cursor: "pointer", gap: 10, width: "100%", textAlign: "left" }}
        >
          <span className={`switch ${trial ? "on" : ""}`} style={{ pointerEvents: "none" }} />
          <span className="small" style={{ fontSize: 14 }}>
            Сначала <b>7 дней бесплатно</b>, потом {priceMain}
          </span>
        </button>

        <Btn full size="lg" onClick={pay} disabled={phase !== "idle"}>
          {trial ? "Попробовать 7 дней бесплатно" : `Оформить за ${priceMain}`}
        </Btn>
        <p className="tiny" style={{ textAlign: "center", marginTop: 12 }}>
          Демо-режим макета: оплата не списывается. В продакшне — RuStore Billing / ЮKassa, отмена в любой момент.
        </p>
      </div>

      <Modal open={phase !== "idle"}>
        {phase === "processing" ? (
          <div style={{ padding: "10px 0" }}>
            <div className="spinner big" style={{ margin: "0 auto 16px" }} />
            <h3 className="h-3">Оформляем подписку…</h3>
            <p className="small" style={{ marginTop: 6 }}>Без списаний: это макет оплаты</p>
          </div>
        ) : (
          <div style={{ padding: "10px 0" }}>
            <SuccessMark />
            <h3 className="h-3" style={{ marginTop: 14 }}>Готово! Premium активен</h3>
            <p className="small" style={{ marginTop: 6 }}>Карта личности и все практики открыты</p>
          </div>
        )}
      </Modal>
    </div>
  );
}

// ───────────────────────── Сообщество ─────────────────────────

export function Community() {
  const { state, addPost, toggleHeart, toast } = useApp();
  const loading = useFakeLoad(480);
  const [tick, setTick] = useState(0);
  const [compose, setCompose] = useState(false);
  const [text, setText] = useState("");
  const online = typeof navigator === "undefined" ? true : navigator.onLine;

  const posts = useMemo(() => {
    const likedSet = new Set(state.likedPosts);
    const mine = state.myPosts.map((p) => ({ ...p, liked: false, mine: true as boolean }));
    const seed = COMMUNITY_SEED.map((p) => ({
      ...p,
      hearts: p.hearts + (likedSet.has(p.id) ? 1 : 0),
      liked: likedSet.has(p.id),
      mine: false as boolean,
    }));
    return [...mine, ...seed];
  }, [state.myPosts, state.likedPosts]);

  const publish = () => {
    if (!text.trim()) return;
    addPost(text);
    setText("");
    setCompose(false);
    toast("Опубликовано анонимно. Спасибо за открытость");
  };

  return (
    <div className="screen">
      <div className="screen-pad" style={{ paddingTop: 66 }}>
        <div className="between" style={{ marginBottom: 14 }}>
          <div>
            <h1 className="h-1">Сообщество</h1>
            <p className="small" style={{ marginTop: 4 }}>Анонимная лента поддержки — без оценок и советов «просто не грусти».</p>
          </div>
          <button className="back-btn" onClick={() => setTick((t) => t + 1)} aria-label="Обновить ленту">
            <RefreshCw size={17} />
          </button>
        </div>

        <div className="notice" style={{ marginBottom: 16 }}>
          <Users size={15} style={{ flexShrink: 0, marginTop: 1, color: "#0e7490" }} />
          <span>Псевдонимы генерируются автоматически, личные данные не публикуются.</span>
        </div>

        {!online ? (
          <ErrorState onRetry={() => setTick(tick + 1)} text="Лента недоступна без сети. SOS и дыхание работают офлайн" />
        ) : loading ? (
          <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            <CardSkeleton lines={3} />
            <CardSkeleton lines={3} />
            <CardSkeleton lines={2} />
          </div>
        ) : posts.length === 0 ? (
          <EmptyState title="Пока тихо" text="Стань первым, кто поделится" actionLabel="Написать" onAction={() => setCompose(true)} />
        ) : (
          <div key={tick} className="stagger" style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            {posts.map((p) => (
              <Card key={p.id} className="post-card">
                <div className="between" style={{ marginBottom: 8 }}>
                  <div className="row" style={{ gap: 8 }}>
                    <span
                      style={{
                        width: 34,
                        height: 34,
                        borderRadius: 12,
                        display: "grid",
                        placeItems: "center",
                        background: p.mine ? "linear-gradient(140deg,#22d3ee,#0e7490)" : "rgba(13,36,48,0.07)",
                        color: p.mine ? "#fff" : "#64798a",
                      }}
                    >
                      <Waves size={16} />
                    </span>
                    <div>
                      <b style={{ fontSize: 14 }}>{p.nick}</b>
                      <p className="tiny" style={{ margin: 0 }}>{p.time}</p>
                    </div>
                  </div>
                </div>
                <p className="body-t" style={{ fontSize: 14.5 }}>{p.text}</p>
                <div style={{ marginTop: 8 }}>
                  <button
                    className={`heart-btn ${p.liked ? "liked" : ""}`}
                    onClick={() => (p.mine ? toast("Своему посту сердце не нужно — ты уже справляешься") : toggleHeart(p.id))}
                    aria-label="Поддержать"
                  >
                    <Heart size={15} fill={p.liked ? "#f97373" : "none"} /> {p.hearts}
                  </button>
                </div>
              </Card>
            ))}
          </div>
        )}

        <div style={{ height: 84 }} />
      </div>

      {/* FAB */}
      <button
        onClick={() => setCompose(true)}
        aria-label="Написать в сообщество"
        style={{
          position: "absolute",
          right: 18,
          bottom: 96,
          zIndex: 30,
          minHeight: 48,
          padding: "0 18px",
          borderRadius: 999,
          border: "none",
          background: "linear-gradient(135deg,#0e7490,#06b6d4)",
          color: "#fff",
          fontWeight: 700,
          fontSize: 14,
          cursor: "pointer",
          boxShadow: "0 14px 30px -10px rgba(8,120,150,0.6)",
          display: "flex",
          alignItems: "center",
          gap: 8,
        }}
      >
        <Heart size={16} /> Поделиться
      </button>

      <Sheet open={compose} onClose={() => setCompose(false)}>
        <h2 className="h-2" style={{ marginBottom: 6 }}>Поделиться анонимно</h2>
        <p className="small" style={{ marginBottom: 14 }}>Твой псевдоним: «Моя волна». Опыт важнее формулировок.</p>
        <textarea
          className="textarea"
          style={{ minHeight: 110, marginBottom: 14 }}
          placeholder="Что сегодня получилось или было трудным?"
          value={text}
          onChange={(e) => setText(e.target.value)}
          maxLength={400}
        />
        <Btn full size="lg" onClick={publish} disabled={!text.trim()}>
          Опубликовать
        </Btn>
      </Sheet>
    </div>
  );
}
