"use client";

import React, { useEffect, useRef, useState } from "react";
import { ArrowRight, Mail, Phone, ShieldCheck, Sparkles } from "lucide-react";
import { ONBOARDING } from "@/lib/data";
import { useApp } from "@/lib/store";
import { Btn, BrandMark, TopBar } from "@/components/ui";

// ───────────────────────── Splash ─────────────────────────

export function Splash() {
  const { hydrated, flowReset } = useApp();
  const done = useRef(false);

  useEffect(() => {
    if (!hydrated || done.current) return;
    done.current = true;
    const t = setTimeout(() => flowReset("onboarding"), 1900);
    return () => clearTimeout(t);
  }, [hydrated, flowReset]);

  return (
    <div
      className="screen"
      style={{
        background: "linear-gradient(170deg, #0a3f52 0%, #0e7490 55%, #062834 100%)",
        display: "grid",
        placeItems: "center",
      }}
    >
      <AmbientWaves />
      <div style={{ textAlign: "center", color: "#eefbff", animation: "popIn .7s var(--ease-out) both" }}>
        <BrandMark size={86} />
        <h1 style={{ margin: "20px 0 8px", fontSize: 32, fontWeight: 700, letterSpacing: "-0.02em" }}>На волне</h1>
        <p style={{ margin: 0, fontSize: 15, color: "rgba(238,251,255,0.75)", lineHeight: 1.5, maxWidth: 240 }}>
          Персональный план развития психологической устойчивости
        </p>
      </div>
    </div>
  );
}

function AmbientWaves() {
  return (
    <svg
      aria-hidden
      style={{ position: "absolute", inset: "auto 0 0 0", width: "100%", height: 260, opacity: 0.55 }}
      viewBox="0 0 375 260"
      preserveAspectRatio="none"
    >
      <path d="M0 120 C 60 80, 120 170, 190 130 S 320 70, 375 120 L375 260 L0 260 Z" fill="rgba(103,232,249,0.14)">
        <animateTransform attributeName="transform" type="translate" values="0 0; -18 8; 0 0" dur="7s" repeatCount="indefinite" />
      </path>
      <path d="M0 160 C 70 120, 140 200, 210 160 S 330 110, 375 155 L375 260 L0 260 Z" fill="rgba(103,232,249,0.12)">
        <animateTransform attributeName="transform" type="translate" values="0 0; 16 -6; 0 0" dur="9s" repeatCount="indefinite" />
      </path>
      <path d="M0 205 C 80 170, 150 235, 230 200 S 330 165, 375 200 L375 260 L0 260 Z" fill="rgba(224,122,95,0.12)">
        <animateTransform attributeName="transform" type="translate" values="0 0; -12 10; 0 0" dur="11s" repeatCount="indefinite" />
      </path>
    </svg>
  );
}

// ───────────────────────── Onboarding ─────────────────────────

const SLIDE_ARTS = [
  // каждый слайд — своя абстрактная волна
  { c1: "#67e8f9", c2: "#0e7490", c3: "rgba(224,122,95,0.5)" },
  { c1: "#5eead4", c2: "#0f766e", c3: "rgba(103,232,249,0.5)" },
  { c1: "#fda4af", c2: "#e07a5f", c3: "rgba(103,232,249,0.45)" },
  { c1: "#a5b4fc", c2: "#6366f1", c3: "rgba(103,232,249,0.5)" },
  { c1: "#fcd34d", c2: "#f59e0b", c3: "rgba(103,232,249,0.5)" },
];

export function Onboarding() {
  const { flowGo } = useApp();
  const [i, setI] = useState(0);
  const slide = ONBOARDING[i];
  const last = i === ONBOARDING.length - 1;
  const art = SLIDE_ARTS[i];

  return (
    <div className="screen" style={{ display: "flex", flexDirection: "column", background: "linear-gradient(180deg,#eaf6fa 0%, #f2f7f9 46%)" }}>
      <div style={{ display: "flex", justifyContent: "flex-end", padding: "58px 18px 0" }}>
        <button
          onClick={() => flowGo("auth")}
          style={{ border: "none", background: "none", color: "#64798a", fontSize: 14, fontWeight: 600, minHeight: 44, cursor: "pointer", padding: "0 8px" }}
        >
          Пропустить
        </button>
      </div>

      <div key={slide.id} style={{ flex: 1, display: "flex", flexDirection: "column", padding: "8px 26px 0" }}>
        <div
          className="anim-in"
          style={{
            height: 240,
            borderRadius: 30,
            background: `linear-gradient(150deg, ${art.c1}, ${art.c2})`,
            position: "relative",
            overflow: "hidden",
            boxShadow: "0 26px 50px -22px rgba(14,116,144,0.5)",
            marginBottom: 30,
          }}
        >
          <svg aria-hidden viewBox="0 0 320 240" preserveAspectRatio="none" style={{ position: "absolute", inset: 0, width: "100%", height: "100%" }}>
            <path d="M0 150 C 50 110, 100 190, 160 150 S 270 100, 320 145 L320 240 L0 240 Z" fill="rgba(255,255,255,0.22)">
              <animateTransform attributeName="transform" type="translate" values="0 0; -14 6; 0 0" dur="6s" repeatCount="indefinite" />
            </path>
            <path d="M0 185 C 60 150, 120 220, 190 180 S 280 140, 320 180 L320 240 L0 240 Z" fill="rgba(255,255,255,0.18)">
              <animateTransform attributeName="transform" type="translate" values="0 0; 12 -6; 0 0" dur="8s" repeatCount="indefinite" />
            </path>
            <circle cx="250" cy="58" r="30" fill={art.c3} opacity="0.8">
              <animate attributeName="cy" values="58;66;58" dur="5s" repeatCount="indefinite" />
            </circle>
            <circle cx="66" cy="70" r="12" fill="rgba(255,255,255,0.5)">
              <animate attributeName="cy" values="70;60;70" dur="6s" repeatCount="indefinite" />
            </circle>
            <circle cx="120" cy="46" r="6" fill="rgba(255,255,255,0.55)" />
          </svg>
        </div>

        <div className="anim-in" style={{ animationDelay: "0.08s" }}>
          <h2 className="h-1" style={{ marginBottom: 12 }}>{slide.title}</h2>
          <p className="body-t">{slide.text}</p>
        </div>

        <div style={{ flex: 1 }} />

        <div style={{ display: "flex", justifyContent: "center", gap: 8, margin: "22px 0" }}>
          {ONBOARDING.map((s, idx) => (
            <button
              key={s.id}
              aria-label={`Слайд ${idx + 1}`}
              onClick={() => setI(idx)}
              style={{
                width: idx === i ? 26 : 8,
                height: 8,
                borderRadius: 99,
                border: "none",
                background: idx === i ? "#0e7490" : "rgba(13,36,48,0.16)",
                cursor: "pointer",
                transition: "all .3s",
                padding: 0,
              }}
            />
          ))}
        </div>

        <div style={{ paddingBottom: 34 }}>
          <Btn full size="lg" onClick={() => (last ? flowGo("auth") : setI(i + 1))}>
            {last ? "Начать" : "Далее"} <ArrowRight size={18} />
          </Btn>
        </div>
      </div>
    </div>
  );
}

// ───────────────────────── Auth ─────────────────────────

export function Auth() {
  const { flowGo, flowBack, update, state, toast } = useApp();
  const [method, setMethod] = useState<"phone" | "email">("phone");
  const [name, setName] = useState(state.user?.name === "Гость" ? "" : state.user?.name ?? "");
  const [contact, setContact] = useState("");
  const [err, setErr] = useState("");
  const [loading, setLoading] = useState(false);

  const validContact = (m: "phone" | "email", v: string) => {
    if (m === "phone") {
      const digits = v.replace(/\D/g, "");
      return digits.length === 11 || (digits.length === 10 && !v.includes("+"));
    }
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v.trim());
  };

  const switchMethod = (m: "phone" | "email") => {
    setMethod(m);
    setContact("");
    setErr("");
  };

  const submit = () => {
    if (!validContact(method, contact)) {
      setErr(method === "phone" ? "Введи номер полностью: +7 900 000-00-00" : "Проверь адрес: должна быть почта вида name@mail.ru");
      return;
    }
    setErr("");
    setLoading(true);
    const displayName = name.trim() || "Друг";
    setTimeout(() => {
      update({ user: { name: displayName, contact: contact.trim(), isGuest: false } });
      setLoading(false);
      flowGo("verify");
    }, 900);
  };

  const guest = () => {
    update({ user: { name: name.trim() || "Гость", contact: "", isGuest: true } });
    toast("Гостевой режим: данные только на этом устройстве");
    flowGo("testCover");
  };

  return (
    <div className="screen">
      <TopBar onBack={flowBack} />
      <div className="screen-pad anim-in" style={{ paddingTop: 10 }}>
        <h1 className="h-display" style={{ marginBottom: 10 }}>Создай свой профиль</h1>
        <p className="body-t" style={{ marginBottom: 24 }}>Чтобы сохранять план, прогресс и открыть доступ с любого устройства.</p>

        <label className="label" htmlFor="auth-name">Как к тебе обращаться?</label>
        <input
          id="auth-name"
          className="input"
          placeholder="Имя"
          value={name}
          onChange={(e) => setName(e.target.value)}
          autoComplete="name"
          style={{ marginBottom: 18 }}
        />

        <div className="seg" style={{ marginBottom: 14 }}>
          <button className={method === "phone" ? "active" : ""} onClick={() => switchMethod("phone")}>
            <span className="row" style={{ justifyContent: "center", gap: 6 }}><Phone size={15} /> Телефон</span>
          </button>
          <button className={method === "email" ? "active" : ""} onClick={() => switchMethod("email")}>
            <span className="row" style={{ justifyContent: "center", gap: 6 }}><Mail size={15} /> Email</span>
          </button>
        </div>

        <label className="label" htmlFor="auth-contact">
          {method === "phone" ? "Номер телефона" : "Электронная почта"}
        </label>
        <input
          id="auth-contact"
          className="input"
          style={err ? { borderColor: "#f87171" } : undefined}
          placeholder={method === "phone" ? "+7 900 000-00-00" : "name@mail.ru"}
          inputMode={method === "phone" ? "tel" : "email"}
          autoComplete={method === "phone" ? "tel" : "email"}
          value={contact}
          onChange={(e) => { setContact(e.target.value); setErr(""); }}
          onKeyDown={(e) => e.key === "Enter" && submit()}
        />
        {err && <p className="field-error">{err}</p>}

        <div style={{ height: 20 }} />
        <Btn full size="lg" onClick={submit} disabled={loading}>
          {loading ? <span className="spinner" style={{ borderColor: "rgba(255,255,255,0.3)", borderTopColor: "#fff" }} /> : <>Получить код <ArrowRight size={18} /></>}
        </Btn>

        <div className="row" style={{ margin: "18px 0", gap: 12 }}>
          <div style={{ flex: 1, height: 1, background: "rgba(13,36,48,0.1)" }} />
          <span className="tiny">или</span>
          <div style={{ flex: 1, height: 1, background: "rgba(13,36,48,0.1)" }} />
        </div>

        <Btn full variant="outline" onClick={guest}>Продолжить как гость</Btn>

        <div className="notice" style={{ marginTop: 22 }}>
          <ShieldCheck size={16} style={{ flexShrink: 0, marginTop: 1, color: "#0e7490" }} />
          <span>Данные защищены по 152-ФЗ. Ответы тестов не передаются третьим лицам и не используются в рекламе.</span>
        </div>
      </div>
    </div>
  );
}

// ───────────────────────── Verify ─────────────────────────

export function Verify() {
  const { flowGo, flowBack, update, toast, state } = useApp();
  const [digits, setDigits] = useState<string[]>(["", "", "", ""]);
  const [error, setError] = useState(false);
  const [resendIn, setResendIn] = useState(25);
  const refs = [useRef<HTMLInputElement>(null), useRef<HTMLInputElement>(null), useRef<HTMLInputElement>(null), useRef<HTMLInputElement>(null)];

  useEffect(() => {
    refs[0].current?.focus();
    const t = setInterval(() => setResendIn((s) => (s > 0 ? s - 1 : 0)), 1000);
    return () => clearInterval(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const tryCode = (code: string) => {
    if (code === "0000") {
      update({ user: state.user ? { ...state.user } : { name: "Друг", contact: "", isGuest: false } });
      toast("Код принят. Добро пожаловать!");
      flowGo("testCover");
    } else {
      setError(true);
      setTimeout(() => {
        setDigits(["", "", "", ""]);
        setError(false);
        refs[0].current?.focus();
      }, 500);
    }
  };

  const setDigit = (i: number, v: string) => {
    const c = v.replace(/\D/g, "").slice(-1);
    const next = [...digits];
    next[i] = c;
    setDigits(next);
    if (c && i < 3) refs[i + 1].current?.focus();
    const code = next.join("");
    if (next.every((d) => d) && code.length === 4) setTimeout(() => tryCode(code), 120);
  };

  return (
    <div className="screen">
      <TopBar onBack={flowBack} />
      <div className="screen-pad anim-in" style={{ paddingTop: 10 }}>
        <h1 className="h-display" style={{ marginBottom: 10 }}>Введи код</h1>
        <p className="body-t" style={{ marginBottom: 6 }}>
          Мы отправили код на <b>{state.user?.contact || "твой контакт"}</b>
        </p>
        <p className="small" style={{ marginBottom: 26 }}>
          <Sparkles size={13} style={{ verticalAlign: -2, marginRight: 4, color: "#0e7490" }} />
          Демо-режим: код — <b>0000</b>
        </p>

        <div className="row" style={{ justifyContent: "center", gap: 10, marginBottom: 18 }}>
          {digits.map((d, i) => (
            <input
              key={i}
              ref={refs[i]}
              className={`code-box ${error ? "err" : ""}`}
              inputMode="numeric"
              maxLength={1}
              value={d}
              aria-label={`Цифра ${i + 1}`}
              onChange={(e) => setDigit(i, e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Backspace" && !digits[i] && i > 0) refs[i - 1].current?.focus();
              }}
            />
          ))}
        </div>
        {error && <p className="field-error" style={{ textAlign: "center", marginTop: 0 }}>Код не подошёл. Попробуй 0000</p>}

        <div style={{ textAlign: "center", marginTop: 14 }}>
          {resendIn > 0 ? (
            <span className="small">Отправить код снова через {resendIn} с</span>
          ) : (
            <button
              onClick={() => { setResendIn(25); toast("Код отправлен повторно"); }}
              style={{ border: "none", background: "none", color: "#0e7490", fontWeight: 700, fontSize: 14, cursor: "pointer", minHeight: 44 }}
            >
              Отправить код снова
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
