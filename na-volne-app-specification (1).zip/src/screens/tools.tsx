"use client";

import React, { useEffect, useMemo, useRef, useState } from "react";
import {
  ArrowRight,
  AudioLines,
  BedDouble,
  BookOpen,
  GraduationCap,
  Heart,
  HeartHandshake,
  Lock,
  NotebookPen,
  Pause,
  PersonStanding,
  Play,
  Scan,
  Timer,
  Volume2,
  Wind,
} from "lucide-react";
import {
  BODY_PRACTICES,
  COURSES,
  SOUNDSCAPES,
  TECHNIQUES,
  TECHNIQUE_FILTERS,
  PLAYER_TIMERS,
  techniqueById,
  type Course,
} from "@/lib/data";
import { useApp } from "@/lib/store";
import {
  Btn,
  Card,
  CardSkeleton,
  Chip,
  EmptyState,
  LockBadge,
  Progress,
  RadarPenta,
  Ring,
  TopBar,
  useFakeLoad,
} from "@/components/ui";

// ───────────────────────── Меню инструментов ─────────────────────────

export function Tools() {
  const { go, state } = useApp();
  const loading = useFakeLoad(380);
  if (loading)
    return (
      <div className="screen">
        <div className="screen-pad" style={{ display: "flex", flexDirection: "column", gap: 14, paddingTop: 70 }}>
          <CardSkeleton lines={2} />
          <CardSkeleton lines={2} />
          <CardSkeleton lines={2} />
        </div>
      </div>
    );

  const items = [
    {
      id: "map",
      title: "Карта личности",
      sub: "Сильные стороны, зоны роста, паттерны",
      icon: Scan,
      grad: "linear-gradient(140deg,#67e8f9,#0e7490)",
      premium: true,
      route: "map" as const,
    },
    { id: "courses", title: "Мини-курсы", sub: "Границы, фокус, уверенность, энергия", icon: BookOpen, grad: "linear-gradient(140deg,#fcd34d,#e07a5f)", route: "courses" as const },
    { id: "techniques", title: "Техники самопомощи", sub: "12 практик с доказательной базой", icon: Wind, grad: "linear-gradient(140deg,#5eead4,#0f766e)", route: "techniques" as const },
    {
      id: "soundscapes",
      title: "Саундскейпы",
      sub: "Фокус-сессии и звуки для сна",
      icon: AudioLines,
      grad: "linear-gradient(140deg,#a5b4fc,#4f46e5)",
      route: "soundscapes" as const,
    },
    {
      id: "body",
      title: "Телесные практики",
      sub: "Аудио и видео-сессии с таймером",
      icon: PersonStanding,
      grad: "linear-gradient(140deg,#fda4af,#e07a5f)",
      premium: true,
      route: "body" as const,
    },
    { id: "diary", title: "Дневник мыслей (КПТ)", sub: "Разбор мыслей, тревог, благодарность", icon: NotebookPen, grad: "linear-gradient(140deg,#93c5fd,#1e3a8a)", route: "diary" as const },
    { id: "sleep", title: "Настроение и привычки", sub: "Сон ↔ настроение ↔ энергия", icon: BedDouble, grad: "linear-gradient(140deg,#c4b5fd,#7c3aed)", route: "sleep" as const },
  ];

  return (
    <div className="screen">
      <div className="screen-pad" style={{ paddingTop: 66 }}>
        <h1 className="h-1" style={{ marginBottom: 6 }}>Инструменты</h1>
        <p className="body-t" style={{ marginBottom: 18 }}>Всё для ежедневной заботы о себе — в одном месте.</p>
        <div className="stagger" style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          {items.map((it) => {
            const locked = Boolean(it.premium) && !state.premium;
            return (
              <Card key={it.id} pressable onClick={() => go(it.route)}>
                <div className="row">
                  <div className="icon-tile" style={{ background: it.grad }}>
                    <it.icon size={22} />
                  </div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div className="row" style={{ gap: 8 }}>
                      <h3 className="h-3">{it.title}</h3>
                      {locked && <LockBadge />}
                    </div>
                    <p className="small" style={{ marginTop: 2 }}>{it.sub}</p>
                  </div>
                  <ArrowRight size={18} color="#64798a" />
                </div>
              </Card>
            );
          })}
        </div>
      </div>
    </div>
  );
}

// ───────────────────────── Карта личности ─────────────────────────

export function MapScreen() {
  const { back, state, streak, openPaywall } = useApp();
  const loading = useFakeLoad(460);

  const axes = useMemo(() => {
    const r = state.result;
    const clamp = (v: number) => Math.max(4, Math.min(100, Math.round(v)));
    return [
      { label: "Энергия", pct: clamp(100 - (r?.scales.burnout.pct ?? 58)) },
      { label: "Спокойствие", pct: clamp(100 - (r?.scales.anxiety.pct ?? 55)) },
      { label: "Собранность", pct: clamp(100 - (r?.scales.stress.pct ?? 60)) },
      { label: "Регулярность", pct: clamp(streak * 14 + state.checkins.length * 3 + 18) },
      { label: "Рефлексия", pct: clamp(18 + state.diary.length * 18 + state.gratitudes.length * 8) },
    ];
  }, [state.result, state.checkins.length, state.diary.length, state.gratitudes.length, streak]);

  const strengths = useMemo(() => {
    const sorted = [...axes].sort((a, b) => b.pct - a.pct);
    return sorted.slice(0, 2).map((a) => a.label);
  }, [axes]);
  const growth = useMemo(() => {
    const sorted = [...axes].sort((a, b) => a.pct - b.pct);
    return sorted.slice(0, 2).map((a) => a.label);
  }, [axes]);

  return (
    <div className="screen">
      <TopBar title="Карта личности" onBack={back} />
      <div className="screen-pad" style={{ paddingTop: 6 }}>
        {loading ? (
          <>
            <CardSkeleton lines={4} />
            <CardSkeleton lines={3} />
          </>
        ) : !state.premium ? (
          <div className="anim-in">
            <Card style={{ position: "relative", overflow: "hidden", padding: 0 }}>
              <div style={{ filter: "blur(7px)", opacity: 0.6, padding: 12 }}>
                <RadarPenta axes={axes} />
              </div>
              <div
                style={{
                  position: "absolute",
                  inset: 0,
                  display: "grid",
                  placeItems: "center",
                  background: "linear-gradient(180deg, rgba(242,247,249,0.2), rgba(242,247,249,0.88) 60%)",
                }}
              >
                <div style={{ textAlign: "center", padding: 20 }}>
                  <div
                    style={{
                      width: 56,
                      height: 56,
                      margin: "0 auto 10px",
                      borderRadius: 18,
                      display: "grid",
                      placeItems: "center",
                      background: "linear-gradient(140deg,#fcd34d,#e07a5f)",
                      color: "#fff",
                    }}
                  >
                    <Lock size={24} />
                  </div>
                  <h3 className="h-3">Карта личности — Premium</h3>
                  <p className="small" style={{ margin: "6px 0 14px" }}>
                    Агрегация тестов, чек-инов и дневника в живую карту: черты, сильные стороны, зоны роста
                  </p>
                  <Btn onClick={() => openPaywall("map")}>Открыть с Premium</Btn>
                </div>
              </div>
            </Card>
          </div>
        ) : (
          <div className="anim-in" style={{ display: "flex", flexDirection: "column", gap: 14 }}>
            <Card style={{ padding: "10px 6px 16px" }}>
              <RadarPenta axes={axes} />
              <p className="tiny" style={{ textAlign: "center", marginTop: 2 }}>
                Обновлено сегодня на основе теста, чек-инов и записей
              </p>
            </Card>
            <Card>
              <h3 className="h-3" style={{ marginBottom: 8 }}>Сильные стороны</h3>
              <div className="row" style={{ flexWrap: "wrap", gap: 8 }}>
                {strengths.map((s) => (
                  <span key={s} className="chip active" style={{ cursor: "default" }}>{s}</span>
                ))}
              </div>
            </Card>
            <Card>
              <h3 className="h-3" style={{ marginBottom: 8 }}>Зоны роста</h3>
              <div className="row" style={{ flexWrap: "wrap", gap: 8 }}>
                {growth.map((s) => (
                  <span key={s} className="chip" style={{ cursor: "default", background: "rgba(249,115,22,0.12)", border: "none", color: "#c2410c" }}>
                    {s}
                  </span>
                ))}
              </div>
              <p className="small" style={{ marginTop: 10 }}>План на 21 день уже строится вокруг этих зон — без давления.</p>
            </Card>
            <Card>
              <h3 className="h-3" style={{ marginBottom: 6 }}>Паттерны</h3>
              <p className="body-t" style={{ fontSize: 14.5 }}>
                {state.checkins.length >= 3
                  ? "Чек-ины регулярные — метрики устойчивости растут. Обрати внимание на связь сна и настроения в трекере."
                  : "Мало данных для паттернов: три чек-ина подряд — и карта начнёт замечать твои связи."}
              </p>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}

// ───────────────────────── Курсы ─────────────────────────

export function Courses() {
  const { back, go, state } = useApp();
  const loading = useFakeLoad(420);

  return (
    <div className="screen">
      <TopBar title="Мини-курсы" onBack={back} />
      <div className="screen-pad" style={{ paddingTop: 6 }}>
        {loading ? (
          <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            <CardSkeleton lines={4} />
            <CardSkeleton lines={4} />
            <CardSkeleton lines={4} />
          </div>
        ) : (
          <div className="stagger" style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            {COURSES.map((c) => {
              const doneCount = (state.completedLessons[c.id] ?? []).length;
              const locked = c.premium && !state.premium;
              const hue: Record<string, string> = {
                teal: "linear-gradient(140deg,#5eead4,#0f766e)",
                violet: "linear-gradient(140deg,#c4b5fd,#7c3aed)",
                amber: "linear-gradient(140deg,#fcd34d,#e07a5f)",
                cyan: "linear-gradient(140deg,#67e8f9,#0e7490)",
              };
              return (
                <Card key={c.id} pressable onClick={() => go("course", { id: c.id })}>
                  <div className="row" style={{ alignItems: "flex-start" }}>
                    <div className="icon-tile" style={{ background: hue[c.hue] ?? hue.teal }}>
                      <GraduationCap size={22} />
                    </div>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div className="row" style={{ gap: 8, flexWrap: "wrap" }}>
                        <h3 className="h-3">{c.title}</h3>
                        {locked && <LockBadge />}
                        {!c.premium && (
                          <span className="chip" style={{ minHeight: 26, cursor: "default", fontSize: 11, background: "rgba(16,185,129,0.12)", border: "none", color: "#0e9f6e" }}>
                            Бесплатный
                          </span>
                        )}
                      </div>
                      <p className="small" style={{ marginTop: 3 }}>{c.pain}</p>
                      <div style={{ marginTop: 10 }}>
                        <Progress value={(doneCount / c.lessons.length) * 100} />
                        <p className="tiny" style={{ marginTop: 6 }}>
                          {doneCount} из {c.lessons.length} уроков
                        </p>
                      </div>
                    </div>
                  </div>
                </Card>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

export function CourseScreen() {
  const { back, go, current, state, openPaywall } = useApp();
  const course = useMemo(() => COURSES.find((c) => c.id === current.params?.id) ?? COURSES[0], [current.params]);
  const doneList = state.completedLessons[course.id] ?? [];
  const lockedCourse = course.premium && !state.premium;

  return (
    <div className="screen">
      <TopBar onBack={back} />
      <div className="screen-pad" style={{ paddingTop: 6 }}>
        <p className="eyebrow">Мини-курс</p>
        <h1 className="h-1" style={{ marginBottom: 8 }}>{course.title}</h1>
        <p className="body-t" style={{ marginBottom: 8 }}>{course.desc}</p>
        <p className="small" style={{ marginBottom: 18 }}>
          {course.lessons.length} {course.lessons.length === 5 ? "уроков" : "урока"} • по 2–5 минут
        </p>

        {lockedCourse && (
          <div className="notice warn" style={{ marginBottom: 14 }}>
            <Lock size={15} style={{ flexShrink: 0, marginTop: 2, color: "#c2410c" }} />
            <span>Полный курс — в Premium. Первый урок открыт, чтобы попробовать формат.</span>
          </div>
        )}

        <div className="stagger" style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {course.lessons.map((l, i) => {
            const done = doneList.includes(l.id);
            const lessonLocked = lockedCourse && !l.free;
            return (
              <Card
                key={l.id}
                pressable
                onClick={() => (lessonLocked ? openPaywall("lesson") : go("lesson", { course: course.id, id: l.id }))}
              >
                <div className="row">
                  <span
                    className="icon-tile"
                    style={{
                      width: 38,
                      height: 38,
                      borderRadius: 12,
                      background: done ? "linear-gradient(140deg,#34d399,#0e9f6e)" : "rgba(13,36,48,0.07)",
                      color: done ? "#fff" : "#64798a",
                      fontWeight: 800,
                      fontSize: 15,
                    }}
                  >
                    {done ? "✓" : i + 1}
                  </span>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <h3 className="h-3" style={{ fontSize: 15.5 }}>{l.title}</h3>
                    <p className="tiny">{l.minutes} мин{l.exercise ? " • с упражнением" : ""}{l.free && lockedCourse ? " • открыт" : ""}</p>
                  </div>
                  {lessonLocked ? <Lock size={17} color="#b45309" /> : <ArrowRight size={18} color="#64798a" />}
                </div>
              </Card>
            );
          })}
        </div>

        {lockedCourse && (
          <div style={{ marginTop: 16 }}>
            <Btn full onClick={() => openPaywall("course")}>Открыть все курсы с Premium</Btn>
          </div>
        )}
      </div>
    </div>
  );
}

export function LessonScreen() {
  const { back, current, completeLesson, state, toast } = useApp();
  const course: Course = useMemo(() => COURSES.find((c) => c.id === current.params?.course) ?? COURSES[0], [current.params]);
  const lesson = useMemo(
    () => course.lessons.find((l) => l.id === current.params?.id) ?? course.lessons[0],
    [course, current.params]
  );
  const done = (state.completedLessons[course.id] ?? []).includes(lesson.id);

  return (
    <div className="screen">
      <TopBar title={course.title} onBack={back} />
      <div className="screen-pad" style={{ paddingTop: 6 }}>
        <div className="anim-in">
          <p className="eyebrow">Урок • {lesson.minutes} мин</p>
          <h1 className="h-2" style={{ marginBottom: 16 }}>{lesson.title}</h1>

          <Card style={{ marginBottom: 14 }}>
            {lesson.theory.map((p, i) => (
              <p key={i} className="body-t" style={{ marginBottom: i === lesson.theory.length - 1 ? 0 : 12, fontSize: 15 }}>
                {p}
              </p>
            ))}
          </Card>

          {lesson.exercise && (
            <Card style={{ marginBottom: 18, background: "linear-gradient(150deg,#ecfdfd,#f0fbff)" }}>
              <div className="row" style={{ gap: 10, marginBottom: 10 }}>
                <div className="icon-tile" style={{ background: "linear-gradient(140deg,#5eead4,#0f766e)", width: 38, height: 38, borderRadius: 12 }}>
                  <HeartHandshake size={19} />
                </div>
                <h3 className="h-3">{lesson.exercise.title}</h3>
              </div>
              {lesson.exercise.steps.map((s, i) => (
                <div key={i} className="row" style={{ alignItems: "flex-start", gap: 10, padding: "6px 0" }}>
                  <span style={{ width: 24, height: 24, borderRadius: 9, display: "grid", placeItems: "center", background: "rgba(15,118,110,0.12)", color: "#0f766e", fontWeight: 800, fontSize: 12.5, flexShrink: 0 }}>
                    {i + 1}
                  </span>
                  <span className="body-t" style={{ fontSize: 14.5 }}>{s}</span>
                </div>
              ))}
            </Card>
          )}

          <Btn
            full
            variant={done ? "outline" : "primary"}
            onClick={() => {
              completeLesson(course.id, lesson.id);
              toast(done ? "Урок открыт снова" : "Урок пройден — отличная работа");
            }}
          >
            {done ? "Пройден — отметить снова" : "Завершить урок"}
          </Btn>
        </div>
      </div>
    </div>
  );
}

// ───────────────────────── Техники ─────────────────────────

export function Techniques() {
  const { back, go, state, todayKey } = useApp();
  const loading = useFakeLoad(380);
  const [filter, setFilter] = useState("all");
  const list = TECHNIQUES.filter((t) => filter === "all" || t.tags.includes(filter));
  const doneToday = state.doneTechniques[todayKey] ?? [];

  return (
    <div className="screen">
      <TopBar title="Техники самопомощи" onBack={back} />
      <div style={{ padding: "6px 20px 0", position: "sticky", top: 0, zIndex: 5, background: "linear-gradient(180deg, var(--paper) 85%, transparent)" }}>
        <div className="row" style={{ gap: 8, overflowX: "auto", scrollbarWidth: "none", paddingBottom: 12 }}>
          {TECHNIQUE_FILTERS.map((f) => (
            <Chip key={f.id} active={filter === f.id} onClick={() => setFilter(f.id)}>
              {f.label}
            </Chip>
          ))}
        </div>
      </div>
      <div className="screen-pad" style={{ paddingTop: 0 }}>
        {loading ? (
          <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            <CardSkeleton lines={3} />
            <CardSkeleton lines={3} />
          </div>
        ) : list.length === 0 ? (
          <EmptyState title="Пока пусто" text="Попробуй другую категорию" actionLabel="Показать все" onAction={() => setFilter("all")} />
        ) : (
          <div className="stagger" style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            {list.map((t) => {
              const done = doneToday.includes(t.id);
              return (
                <Card key={t.id} pressable onClick={() => go("technique", { id: t.id })}>
                  <div className="row">
                    <div
                      className="icon-tile"
                      style={{
                        background: done
                          ? "linear-gradient(140deg,#34d399,#0e9f6e)"
                          : "linear-gradient(140deg,#5eead4,#0f766e)",
                      }}
                    >
                      {done ? <Heart size={20} /> : <Wind size={22} />}
                    </div>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div className="row" style={{ gap: 8, flexWrap: "wrap" }}>
                        <h3 className="h-3">{t.title}</h3>
                        {t.premium && !state.premium && <LockBadge />}
                      </div>
                      <p className="small" style={{ marginTop: 2 }}>
                        {t.sub} • {t.minutes} мин
                      </p>
                    </div>
                    <ArrowRight size={18} color="#64798a" />
                  </div>
                </Card>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

export function TechniqueScreen() {
  const { back, current, state, completeTechnique, toast, todayKey, openPaywall } = useApp();
  const t = techniqueById(current.params?.id ?? "") ?? TECHNIQUES[0];
  const locked = Boolean(t.premium) && !state.premium;
  const doneToday = (state.doneTechniques[todayKey] ?? []).includes(t.id);
  const [checks, setChecks] = useState<boolean[]>(t.steps.map(() => false));
  const [secondsLeft, setSecondsLeft] = useState(t.minutes * 60);
  const [running, setRunning] = useState(false);

  useEffect(() => {
    if (!running) return;
    const id = setInterval(() => setSecondsLeft((s) => (s > 0 ? s - 1 : 0)), 1000);
    return () => clearInterval(id);
  }, [running]);

  useEffect(() => {
    if (secondsLeft === 0 && running) {
      setRunning(false);
      toast("Время вышло. Как ощущения?");
    }
  }, [secondsLeft, running, toast]);

  const allDone = checks.every(Boolean);
  const mm = Math.floor(secondsLeft / 60);
  const ss = `${secondsLeft % 60}`.padStart(2, "0");

  if (locked) {
    return (
      <div className="screen">
        <TopBar title={t.title} onBack={back} />
        <div className="screen-pad" style={{ paddingTop: 6 }}>
          <EmptyState
            icon={<Lock size={26} />}
            title="Практика в Premium"
            text="Открой все 12 техник, полные курсы и саундскейпы без лимита"
            actionLabel="Смотреть Premium"
            onAction={() => openPaywall("technique")}
          />
        </div>
      </div>
    );
  }

  return (
    <div className="screen">
      <TopBar title={t.title} onBack={back} />
      <div className="screen-pad" style={{ paddingTop: 6 }}>
        <div className="anim-in">
          <div className="row" style={{ gap: 8, marginBottom: 14 }}>
            <span className="chip" style={{ minHeight: 30, cursor: "default" }}>
              <Timer size={13} /> {t.minutes} мин
            </span>
            <span className="chip" style={{ minHeight: 30, cursor: "default", background: "rgba(6,182,212,0.1)", border: "none", color: "#0e7490" }}>
              {t.pain}
            </span>
          </div>
          <p className="body-t" style={{ marginBottom: 18 }}>{t.sub}.</p>

          {/* таймер практики */}
          <Card style={{ marginBottom: 14, textAlign: "center", background: "linear-gradient(150deg,#0b3f52,#0e7490)", color: "#eafafe", border: "none" }}>
            <p className="tiny" style={{ color: "rgba(234,250,254,0.7)", letterSpacing: "0.1em", textTransform: "uppercase" }}>Таймер практики</p>
            <p style={{ fontSize: 44, fontWeight: 800, fontVariantNumeric: "tabular-nums", margin: "6px 0 12px", letterSpacing: "-0.02em" }}>
              {mm}:{ss}
            </p>
            <div className="row" style={{ justifyContent: "center", gap: 10 }}>
              <Btn variant="white" size="sm" onClick={() => setRunning(!running)}>
                {running ? <Pause size={15} /> : <Play size={15} />} {running ? "Пауза" : "Старт"}
              </Btn>
              <Btn
                variant="ghost"
                size="sm"
                style={{ color: "rgba(234,250,254,0.85)" }}
                onClick={() => { setRunning(false); setSecondsLeft(t.minutes * 60); }}
              >
                Сброс
              </Btn>
            </div>
          </Card>

          <Card style={{ marginBottom: 18, padding: "8px 16px" }}>
            {t.steps.map((s, i) => (
              <button
                key={i}
                className={`check-row ${checks[i] ? "done" : ""}`}
                onClick={() => setChecks((c) => c.map((v, j) => (j === i ? !v : v)))}
              >
                <span className="check-box">{checks[i] && "✓"}</span>
                <span className="check-tx body-t" style={{ fontSize: 14.5 }}>{s}</span>
              </button>
            ))}
          </Card>

          <Btn
            full
            size="lg"
            variant={doneToday ? "outline" : "primary"}
            disabled={!doneToday && !allDone}
            onClick={() => {
              completeTechnique(t.id);
              toast("Практика засчитана. Бережно продолжай");
            }}
          >
            {doneToday ? "Выполнено сегодня" : allDone ? "Завершить практику" : "Отметь все шаги"}
          </Btn>
        </div>
      </div>
    </div>
  );
}

// ───────────────────────── Саундскейпы ─────────────────────────

export function Soundscapes() {
  const { back, go, state, openPaywall } = useApp();
  const loading = useFakeLoad(380);

  return (
    <div className="screen">
      <TopBar title="Саундскейпы" onBack={back} />
      <div className="screen-pad" style={{ paddingTop: 6 }}>
        <p className="body-t" style={{ marginBottom: 16 }}>Фоновые звуки для фокуса, восстановления и засыпания.</p>
        {loading ? (
          <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            <CardSkeleton lines={2} />
            <CardSkeleton lines={2} />
          </div>
        ) : (
          <div className="stagger" style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            {SOUNDSCAPES.map((s) => {
              const locked = Boolean(s.premium) && !state.premium;
              return (
                <Card
                  key={s.id}
                  pressable
                  style={{ padding: 0, overflow: "hidden" }}
                  onClick={() => (locked ? openPaywall("sound") : go("player", { id: s.id }))}
                >
                  <div style={{ height: 84, background: `linear-gradient(135deg, ${s.from}, ${s.to})`, position: "relative" }}>
                    <svg aria-hidden viewBox="0 0 320 84" preserveAspectRatio="none" style={{ position: "absolute", inset: 0, width: "100%", height: "100%" }}>
                      <path d="M0 52 C 50 34, 90 66, 150 50 S 260 30, 320 50 L320 84 L0 84 Z" fill="rgba(255,255,255,0.2)">
                        <animateTransform attributeName="transform" type="translate" values="0 0;-10 4;0 0" dur="7s" repeatCount="indefinite" />
                      </path>
                    </svg>
                    {locked && (
                      <span style={{ position: "absolute", top: 12, right: 12 }}>
                        <LockBadge />
                      </span>
                    )}
                  </div>
                  <div style={{ padding: "12px 16px 14px" }}>
                    <div className="between">
                      <div>
                        <h3 className="h-3">{s.title}</h3>
                        <p className="small">{s.desc}</p>
                      </div>
                      <span className="icon-tile" style={{ width: 40, height: 40, borderRadius: 12, background: "rgba(13,36,48,0.06)", color: "#0e7490" }}>
                        {locked ? <Lock size={17} /> : <Play size={17} />}
                      </span>
                    </div>
                  </div>
                </Card>
              );
            })}
          </div>
        )}
        <p className="tiny" style={{ textAlign: "center", marginTop: 16 }}>
          <Volume2 size={12} style={{ verticalAlign: -2, marginRight: 4 }} />
          Звук синтезируется на устройстве — работает без сети
        </p>
      </div>
    </div>
  );
}

// ── аудио-движок на WebAudio: шум + фильтр + LFO ──

interface NoiseHandle { stop: () => void; setVolume: (v: number) => void }

function startNoise(kind: string): NoiseHandle | null {
  try {
    const Ctx = window.AudioContext ?? (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!Ctx) return null;
    const ctx = new Ctx();
    const len = ctx.sampleRate * 2;
    const buf = ctx.createBuffer(1, len, ctx.sampleRate);
    const data = buf.getChannelData(0);
    let last = 0;
    for (let i = 0; i < len; i++) {
      const white = Math.random() * 2 - 1;
      last = (last + 0.03 * white) / 1.03; // коричневый оттенок
      data[i] = (kind === "rain" ? white * 0.5 : last * 2.4) * 0.6;
    }
    const src = ctx.createBufferSource();
    src.buffer = buf;
    src.loop = true;

    const filter = ctx.createBiquadFilter();
    const presets: Record<string, { type: BiquadFilterType; freq: number; q: number; lfo: number; depth: number; vol: number; rate: number }> = {
      sea: { type: "lowpass", freq: 620, q: 0.7, lfo: 0.11, depth: 320, vol: 0.5, rate: 0.65 },
      rain: { type: "bandpass", freq: 2800, q: 0.5, lfo: 0, depth: 0, vol: 0.32, rate: 1 },
      storm: { type: "lowpass", freq: 380, q: 0.8, lfo: 0.06, depth: 220, vol: 0.6, rate: 0.6 },
      wind: { type: "bandpass", freq: 820, q: 1.6, lfo: 0.14, depth: 420, vol: 0.42, rate: 0.8 },
      deep: { type: "lowpass", freq: 240, q: 0.9, lfo: 0.045, depth: 110, vol: 0.55, rate: 0.5 },
    };
    const p = presets[kind] ?? presets.sea;
    filter.type = p.type;
    filter.frequency.value = p.freq;
    filter.Q.value = p.q;
    src.playbackRate.value = p.rate;

    const gain = ctx.createGain();
    gain.gain.value = 0;
    gain.gain.linearRampToValueAtTime(p.vol, ctx.currentTime + 1.2);

    let lfo: OscillatorNode | null = null;
    let lfoGain: GainNode | null = null;
    if (p.lfo > 0) {
      lfo = ctx.createOscillator();
      lfo.frequency.value = p.lfo;
      lfoGain = ctx.createGain();
      lfoGain.gain.value = p.depth;
      lfo.connect(lfoGain);
      lfoGain.connect(filter.frequency);
      lfo.start();
    }

    src.connect(filter);
    filter.connect(gain);
    gain.connect(ctx.destination);
    src.start();

    return {
      setVolume: (v: number) => gain.gain.setTargetAtTime(v, ctx.currentTime, 0.2),
      stop: () => {
        gain.gain.setTargetAtTime(0, ctx.currentTime, 0.3);
        setTimeout(() => {
          try {
            src.stop();
            lfo?.stop();
            void ctx.close();
          } catch { /* ignore */ }
        }, 800);
      },
    };
  } catch {
    return null;
  }
}

export function Player() {
  const { back, current, toast } = useApp();
  const s = SOUNDSCAPES.find((x) => x.id === current.params?.id) ?? SOUNDSCAPES[0];
  const [playing, setPlaying] = useState(false);
  const [timerSec, setTimerSec] = useState(180);
  const [left, setLeft] = useState<number | null>(null);
  const engine = useRef<NoiseHandle | null>(null);

  useEffect(() => {
    return () => {
      engine.current?.stop();
      engine.current = null;
    };
  }, []);

  useEffect(() => {
    if (!playing || left === null) return;
    const id = setInterval(() => {
      setLeft((v) => {
        if (v === null) return v;
        if (v <= 1) return 0;
        return v - 1;
      });
    }, 1000);
    return () => clearInterval(id);
  }, [playing, left !== null]);

  useEffect(() => {
    if (left === 0 && playing) {
      togglePlay();
      toast("Таймер закончился. Мягкий переход назад в день");
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [left]);

  const togglePlay = () => {
    if (playing) {
      engine.current?.stop();
      engine.current = null;
      setPlaying(false);
      return;
    }
    engine.current = startNoise(s.kind);
    setPlaying(true);
    if (timerSec > 0) setLeft(timerSec);
  };

  const pickTimer = (sec: number) => {
    setTimerSec(sec);
    if (playing) setLeft(sec > 0 ? sec : null);
    else setLeft(null);
  };

  const display = left !== null && playing ? left : timerSec > 0 ? timerSec : null;
  const mm = display !== null ? Math.floor(display / 60) : null;
  const ss = display !== null ? `${display % 60}`.padStart(2, "0") : null;

  return (
    <div
      className="screen"
      style={{ background: `linear-gradient(175deg, ${s.to} 0%, #07202e 80%)`, color: "#eafafe" }}
    >
      <TopBar onBack={back} onDark />
      <div className="screen-pad" style={{ paddingTop: 26, textAlign: "center" }}>
        <div className="anim-in">
          <p style={{ fontSize: 13, letterSpacing: "0.18em", textTransform: "uppercase", color: "rgba(234,250,254,0.6)", margin: "0 0 6px" }}>
            Саундскейп
          </p>
          <h1 style={{ fontSize: 27, fontWeight: 700, margin: "0 0 4px", letterSpacing: "-0.015em" }}>{s.title}</h1>
          <p style={{ margin: "0 0 30px", fontSize: 14.5, color: "rgba(234,250,254,0.72)" }}>{s.desc}</p>

          <div className={`player-orb ${playing ? "playing" : ""}`} style={{ marginBottom: 30 }}>
            <span className="eq" />
            <span className="eq eq2" />
            <button
              className="core"
              onClick={togglePlay}
              aria-label={playing ? "Пауза" : "Слушать"}
              style={{ border: "none", cursor: "pointer", background: `linear-gradient(150deg, ${s.from}, ${s.to})` }}
            >
              {playing ? <Pause size={44} /> : <Play size={44} style={{ marginLeft: 5 }} />}
            </button>
          </div>

          <p style={{ fontSize: 40, fontWeight: 800, fontVariantNumeric: "tabular-nums", margin: "0 0 4px", letterSpacing: "-0.02em" }}>
            {display !== null ? `${mm}:${ss}` : "∞"}
          </p>
          <p style={{ fontSize: 13, color: "rgba(234,250,254,0.6)", margin: "0 0 22px" }}>
            {display !== null ? (playing ? "до тихого финала" : "длительность сессии") : "без лимита времени"}
          </p>

          <div className="row" style={{ justifyContent: "center", gap: 8, flexWrap: "wrap", marginBottom: 26 }}>
            {PLAYER_TIMERS.map((t) => (
              <button
                key={t.sec}
                className="chip"
                onClick={() => pickTimer(t.sec)}
                style={
                  timerSec === t.sec
                    ? { background: "rgba(255,255,255,0.92)", borderColor: "transparent", color: "#0d2430" }
                    : { background: "rgba(255,255,255,0.1)", borderColor: "rgba(255,255,255,0.2)", color: "#eafafe" }
                }
              >
                {t.label}
              </button>
            ))}
          </div>

          <Btn variant="white" full size="lg" onClick={togglePlay}>
            {playing ? (
              <>
                <Pause size={18} /> Остановить
              </>
            ) : (
              <>
                <Play size={18} /> Слушать
              </>
            )}
          </Btn>
        </div>
      </div>
    </div>
  );
}

// ───────────────────────── Телесные практики ─────────────────────────

export function Body() {
  const { back, state, openPaywall, toast } = useApp();
  const locked = !state.premium;

  return (
    <div className="screen">
      <TopBar title="Телесные практики" onBack={back} />
      <div className="screen-pad" style={{ paddingTop: 6 }}>
        <p className="body-t" style={{ marginBottom: 16 }}>
          Тело держит стресс даже когда голова «справляется». Аудио- и видео-сессии с ведущим — для разгрузки.
        </p>
        <div className="stagger" style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          {BODY_PRACTICES.map((b) => (
            <Card key={b.id} pressable onClick={() => (locked ? openPaywall("body") : toast("Воспроизведение сессии — в полной версии"))}>
              <div className="row">
                <div className="icon-tile" style={{ background: "linear-gradient(140deg,#fda4af,#e07a5f)" }}>
                  <PersonStanding size={22} />
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div className="row" style={{ gap: 8 }}>
                    <h3 className="h-3">{b.title}</h3>
                    {locked && <LockBadge />}
                  </div>
                  <p className="small" style={{ marginTop: 2 }}>{b.desc}</p>
                  <p className="tiny" style={{ marginTop: 6 }}>
                    {b.minutes} мин • {b.withVideo ? "аудио + видео" : "аудио"}
                  </p>
                </div>
                {locked ? <Lock size={17} color="#b45309" /> : <Play size={18} color="#0e7490" />}
              </div>
            </Card>
          ))}
        </div>
        {locked && (
          <div style={{ marginTop: 16 }}>
            <Btn full onClick={() => openPaywall("body")}>Открыть практики с Premium</Btn>
          </div>
        )}
      </div>
    </div>
  );
}
