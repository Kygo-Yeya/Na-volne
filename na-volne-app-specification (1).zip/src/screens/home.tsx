"use client";

import React, { useMemo, useState } from "react";
import {
  ArrowRight,
  BatteryCharging,
  BedDouble,
  BookOpen,
  Check,
  Frown,
  Laugh,
  Meh,
  MoonStar,
  PencilLine,
  Smile,
  SmilePlus,
  Sparkles,
  Sunrise,
  Wind,
  Wrench,
  Zap,
} from "lucide-react";
import { COURSES, MOOD_LABELS, TECHNIQUES, plural } from "@/lib/data";
import { useApp } from "@/lib/store";
import { Btn, Card, CardSkeleton, EmptyState, Ring, Sheet, Spark, TopBar, useFakeLoad } from "@/components/ui";

const MOOD_ICONS = [Frown, Meh, Smile, SmilePlus, Laugh];

function greeting(): string {
  const h = new Date().getHours();
  if (h < 6) return "Доброй ночи";
  if (h < 12) return "Доброе утро";
  if (h < 18) return "Добрый день";
  return "Добрый вечер";
}

function ruDate(): string {
  const s = new Intl.DateTimeFormat("ru-RU", { weekday: "long", day: "numeric", month: "long" }).format(new Date());
  return s.charAt(0).toUpperCase() + s.slice(1);
}

// ───────────────────────── Экран «Сегодня» ─────────────────────────

export function Today() {
  const {
    state,
    openCheckin,
    todayCheckin,
    streak,
    planSteps,
    togglePlanStep,
    todayKey,
    chartWeek,
    go,
    requirePremium,
  } = useApp();
  const loading = useFakeLoad(480);

  const done = state.planDone[todayKey] ?? planSteps.map(() => false);
  const doneCount = done.filter(Boolean).length;
  const progress = planSteps.length ? doneCount / planSteps.length : 0;
  const name = state.user?.name ?? "Друг";

  const techOfDay = useMemo(() => {
    const dayNum = Math.floor(Date.now() / 86400000);
    const free = TECHNIQUES.filter((t) => !t.premium);
    return free[dayNum % free.length];
  }, []);

  const nextCourse = useMemo(() => {
    const unfinished = COURSES.find((c) => (state.completedLessons[c.id] ?? []).length < c.lessons.length);
    return unfinished ?? COURSES[0];
  }, [state.completedLessons]);

  if (loading) {
    return (
      <div className="screen">
        <div className="screen-pad" style={{ display: "flex", flexDirection: "column", gap: 14, paddingTop: 70 }}>
          <CardSkeleton lines={2} />
          <CardSkeleton lines={4} />
          <CardSkeleton lines={3} />
        </div>
      </div>
    );
  }

  return (
    <div className="screen">
      <div className="screen-pad-flush">
        <div className="hero-soft" style={{ margin: 0, padding: "92px 22px 20px" }}>
          <div className="between">
            <div>
              <p className="small" style={{ color: "#64798a" }}>{ruDate()}</p>
              <h1 className="h-1" style={{ marginTop: 4 }}>
                {greeting()}, {name}
              </h1>
            </div>
            {streak > 0 && (
              <span
                className="chip"
                style={{ cursor: "default", background: "rgba(224,122,95,0.13)", border: "none", color: "#c2410c", minHeight: 34 }}
                title="Дней подряд с чек-ином"
              >
                <Zap size={14} fill="#c2410c" /> {streak}
              </span>
            )}
          </div>
        </div>

        <div style={{ padding: "14px 20px 0", display: "flex", flexDirection: "column", gap: 14 }}>
          {/* Чек-ин */}
          {todayCheckin ? (
            <Card>
              <div className="between">
                <div className="row">
                  {(() => {
                    const Icon = MOOD_ICONS[todayCheckin.mood - 1];
                    return (
                      <div className="icon-tile" style={{ background: "linear-gradient(140deg,#34d399,#0e9f6e)" }}>
                        <Icon size={22} />
                      </div>
                    );
                  })()}
                  <div>
                    <h3 className="h-3">Настроение отмечено</h3>
                    <p className="small">{MOOD_LABELS[todayCheckin.mood - 1]}
                      {todayCheckin.sleep != null && ` • сон ${todayCheckin.sleep} ч`}
                    </p>
                  </div>
                </div>
                <Btn variant="ghost" size="sm" onClick={openCheckin}>Уточнить</Btn>
              </div>
            </Card>
          ) : (
            <Card pressable onClick={openCheckin} style={{ background: "linear-gradient(140deg,#fff, #eefbfd)" }}>
              <div className="between">
                <div>
                  <h3 className="h-3">Как ты сейчас?</h3>
                  <p className="small" style={{ marginTop: 3 }}>Чек-ин настроения — 10 секунд</p>
                </div>
                <span className="icon-tile" style={{ background: "linear-gradient(140deg,#67e8f9,#0e7490)" }}>
                  <SmilePlus size={22} />
                </span>
              </div>
              <Btn full variant="soft" className="mt-3" onClick={openCheckin}>Отметить состояние</Btn>
            </Card>
          )}

          {/* План на сегодня */}
          <Card>
            <div className="between" style={{ marginBottom: 6 }}>
              <div>
                <p className="tiny" style={{ fontWeight: 700, letterSpacing: "0.08em", textTransform: "uppercase" }}>План на сегодня</p>
                <p className="small" style={{ marginTop: 2 }}>
                  {doneCount} из {planSteps.length} • день {Math.min(streak + 1, 21)} из 21
                </p>
              </div>
              <Ring value={progress} color={progress === 1 ? "#0e9f6e" : "#0e7490"}>
                <span style={{ fontSize: 13, fontWeight: 800, color: progress === 1 ? "#0e9f6e" : "#0e7490" }}>
                  {Math.round(progress * 100)}%
                </span>
              </Ring>
            </div>
            <div>
              {planSteps.map((s, i) => (
                <button key={s} className={`check-row ${done[i] ? "done" : ""}`} onClick={() => togglePlanStep(i)}>
                  <span className="check-box">{done[i] && <Check size={15} strokeWidth={3} />}</span>
                  <span className="check-tx body-t" style={{ fontSize: 14.5 }}>{s}</span>
                </button>
              ))}
            </div>
            {progress === 1 && (
              <div className="notice" style={{ marginTop: 10 }}>
                <Sparkles size={15} style={{ flexShrink: 0, marginTop: 1, color: "#0e7490" }} />
                <span>Все шаги дня выполнены. Маленькие действия — большой ресурс.</span>
              </div>
            )}
          </Card>

          {/* График настроения */}
          <Card>
            <div className="between" style={{ marginBottom: 4 }}>
              <h3 className="h-3">Настроение · 7 дней</h3>
              {state.result && (
                <span className="tiny" style={{ fontWeight: 700, color: "#0e7490" }}>
                  Устойчивость {state.result.resilienceIndex}/100
                </span>
              )}
            </div>
            <Spark values={chartWeek.map((d) => d.mood)} height={70} />
            <div className="between" style={{ marginTop: -2 }}>
              {chartWeek.map((d) => (
                <span key={d.day} className="tiny" style={{ fontSize: 10 }}>
                  {d.label}
                </span>
              ))}
            </div>
          </Card>

          {/* Сон и паттерны */}
          <Card pressable onClick={() => go("sleep")}>
            <div className="between">
              <div className="row">
                <div className="icon-tile" style={{ background: "linear-gradient(140deg,#818cf8,#4f46e5)" }}>
                  <BedDouble size={22} />
                </div>
                <div>
                  <h3 className="h-3">Сон и паттерны</h3>
                  <p className="small">
                    {todayCheckin?.sleep != null ? `Сегодня: ${todayCheckin.sleep} ч сна` : "Отметь сон и найди связи"}
                  </p>
                </div>
              </div>
              <ArrowRight size={18} color="#64798a" />
            </div>
          </Card>

          {/* Техника дня */}
          <Card pressable onClick={() => go("technique", { id: techOfDay.id })}>
            <div className="row">
              <div className="icon-tile" style={{ background: "linear-gradient(140deg,#5eead4,#0f766e)" }}>
                <Wind size={22} />
              </div>
              <div style={{ flex: 1 }}>
                <p className="tiny" style={{ fontWeight: 700, letterSpacing: "0.08em", textTransform: "uppercase" }}>Техника дня</p>
                <h3 className="h-3" style={{ marginTop: 2 }}>{techOfDay.title}</h3>
                <p className="small">{techOfDay.sub} • {techOfDay.minutes} мин</p>
              </div>
              <ArrowRight size={18} color="#64798a" />
            </div>
          </Card>

          {/* Курс */}
          <Card pressable onClick={() => go("course", { id: nextCourse.id, from: "courses" })}>
            <div className="row">
              <div className="icon-tile" style={{ background: "linear-gradient(140deg,#fcd34d,#e07a5f)" }}>
                <BookOpen size={22} />
              </div>
              <div style={{ flex: 1 }}>
                <p className="tiny" style={{ fontWeight: 700, letterSpacing: "0.08em", textTransform: "uppercase" }}>Продолжить курс</p>
                <h3 className="h-3" style={{ marginTop: 2 }}>{nextCourse.title}</h3>
                <p className="small">
                  Пройдено {(state.completedLessons[nextCourse.id] ?? []).length} из {nextCourse.lessons.length} уроков
                </p>
              </div>
              <ArrowRight size={18} color="#64798a" />
            </div>
          </Card>

          <button
            onClick={() => requirePremium("map_teaser", () => go("map"))}
            style={{ border: "none", background: "none", padding: 0, textAlign: "left", cursor: "pointer" }}
          >
            <Card style={{ background: "linear-gradient(135deg,#0b3f52,#0e7490)", color: "#eafafe", border: "none" }}>
              <div className="row">
                <Sunrise size={22} />
                <div style={{ flex: 1 }}>
                  <h3 className="h-3" style={{ color: "#fff" }}>Карта личности</h3>
                  <p style={{ margin: "2px 0 0", fontSize: 13, color: "rgba(234,250,254,0.78)" }}>
                    Твои сильные стороны и зоны роста — по данным тестов и чек-инов
                  </p>
                </div>
                {!state.premium && <span className="lock-badge">Premium</span>}
              </div>
            </Card>
          </button>

          <div style={{ height: 4 }} />
        </div>
      </div>
    </div>
  );
}

// ───────────────────────── Шторка чек-ина ─────────────────────────

export function CheckInSheet() {
  const { checkinOpen, closeCheckin, saveCheckin, toast, todayCheckin } = useApp();
  const [mood, setMood] = useState<number | null>(todayCheckin?.mood ?? null);
  const [note, setNote] = useState(todayCheckin?.note ?? "");
  const [sleep, setSleep] = useState<number>(todayCheckin?.sleep ?? 7);
  const [energy, setEnergy] = useState<number>(todayCheckin?.energy ?? 3);

  const save = () => {
    if (!mood) return;
    saveCheckin(mood, note, sleep, energy);
    closeCheckin();
    toast("Записано. Спасибо, что заботишься о себе");
  };

  return (
    <Sheet open={checkinOpen} onClose={closeCheckin}>
      <h2 className="h-2" style={{ marginBottom: 4 }}>Как ты сейчас?</h2>
      <p className="small" style={{ marginBottom: 18 }}>Ответ честнее, когда он занимает 10 секунд.</p>

      <div className="row" style={{ justifyContent: "space-between", marginBottom: 18 }}>
        {MOOD_LABELS.map((label, i) => {
          const Icon = MOOD_ICONS[i];
          return (
            <button key={label} className={`mood-face ${mood === i + 1 ? "sel" : ""}`} onClick={() => setMood(i + 1)}>
              <span className="mf-ic">
                <Icon size={26} color={mood === i + 1 ? "#0e7490" : "#7c93a1"} />
              </span>
              <span className="mf-lb">{label}</span>
            </button>
          );
        })}
      </div>

      <label className="label" htmlFor="ci-note">Заметка дня — по желанию</label>
      <textarea
        id="ci-note"
        className="textarea"
        placeholder="Одной строкой: что окрашивает день?"
        value={note}
        onChange={(e) => setNote(e.target.value)}
        style={{ minHeight: 72, marginBottom: 16 }}
      />

      <div className="between" style={{ marginBottom: 6 }}>
        <span className="label" style={{ margin: 0 }}>
          <BedDouble size={14} style={{ verticalAlign: -2, marginRight: 5 }} />
          Сон прошлой ночью
        </span>
        <b style={{ color: "#0e7490", fontSize: 14 }}>{sleep} ч</b>
      </div>
      <input
        type="range"
        min={3}
        max={11}
        step={0.5}
        value={sleep}
        onChange={(e) => setSleep(Number(e.target.value))}
        className="slider"
        aria-label="Часы сна"
        style={{ marginBottom: 18 }}
      />

      <div className="between" style={{ marginBottom: 8 }}>
        <span className="label" style={{ margin: 0 }}>
          <BatteryCharging size={14} style={{ verticalAlign: -2, marginRight: 5 }} />
          Энергия
        </span>
      </div>
      <div className="row" style={{ gap: 8, marginBottom: 22 }}>
        {[1, 2, 3, 4, 5].map((v) => (
          <button
            key={v}
            className={`chip ${energy === v ? "active" : ""}`}
            style={{ flex: 1, justifyContent: "center" }}
            onClick={() => setEnergy(v)}
          >
            {v}
          </button>
        ))}
      </div>

      <Btn full size="lg" onClick={save} disabled={!mood}>
        Сохранить
      </Btn>
      {!mood && <p className="tiny" style={{ textAlign: "center", marginTop: 8 }}>Сначала выбери настроение</p>}
    </Sheet>
  );
}

// ───────────────────────── Трекер сна и паттернов ─────────────────────────

export function SleepScreen() {
  const { back, openCheckin, chartWeek, todayCheckin, state } = useApp();
  const loading = useFakeLoad(420);
  const premium = state.premium;
  const { openPaywall } = useApp();

  const sleepVals = chartWeek.map((d) => d.sleep);
  const maxSleep = 12;
  const insight = useMemo(() => {
    const real = chartWeek.filter((d) => d.real || d.mood !== null);
    if (real.length < 3) return "Отмечай сон каждый день — через несколько дней появятся личные связи «сон ↔ настроение».";
    const lowSleep = real.filter((d) => (d.sleep ?? 8) < 6.5 && d.mood !== null);
    const okSleep = real.filter((d) => (d.sleep ?? 8) >= 6.5 && d.mood !== null);
    if (lowSleep.length === 0 || okSleep.length === 0)
      return "Замечаешь связь? Сон, настроение и активность усиливают или ослабляют друг друга.";
    const avg = (arr: typeof real) => arr.reduce((a, d) => a + (d.mood ?? 0), 0) / arr.length;
    const diff = avg(okSleep) - avg(lowSleep);
    if (diff > 0.4) return `Заметная связь: после сна меньше 6,5 ч твоё настроение ниже примерно на ${diff.toFixed(1)} балла.`;
    return "Пока связь «сон ↔ настроение» слабая — продолжай отмечать, картина уточнится.";
  }, [chartWeek]);

  return (
    <div className="screen">
      <TopBar title="Сон и паттерны" onBack={back} />
      <div className="screen-pad" style={{ paddingTop: 8, display: "flex", flexDirection: "column", gap: 14 }}>
        {loading ? (
          <>
            <CardSkeleton lines={3} />
            <CardSkeleton lines={3} />
          </>
        ) : (
          <>
            <Card>
              <div className="between" style={{ marginBottom: 10 }}>
                <h3 className="h-3">Сон · 7 дней</h3>
                {todayCheckin?.sleep == null && (
                  <Btn size="sm" variant="soft" onClick={openCheckin}>
                    Отметить сегодня
                  </Btn>
                )}
              </div>
              <div style={{ display: "flex", alignItems: "flex-end", gap: 8, height: 110, paddingTop: 6 }}>
                {chartWeek.map((d) => (
                  <div key={d.day} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 6 }}>
                    <div
                      title={`${d.sleep ?? "—"} ч`}
                      style={{
                        width: "100%",
                        height: `${((d.sleep ?? 0) / maxSleep) * 84}px`,
                        minHeight: 4,
                        borderRadius: 6,
                        background: d.real
                          ? "linear-gradient(180deg,#818cf8,#4f46e5)"
                          : "repeating-linear-gradient(180deg, rgba(129,140,248,0.5) 0 4px, rgba(129,140,248,0.25) 4px 8px)",
                        transition: "height .4s var(--ease-out)",
                      }}
                    />
                    <span className="tiny" style={{ fontSize: 10 }}>{d.label}</span>
                  </div>
                ))}
              </div>
              <p className="tiny" style={{ marginTop: 6 }}>Столбики — часы сна. Полупрозрачные — демо-фон до первого чек-ина за день.</p>
            </Card>

            <Card>
              <div className="row" style={{ gap: 10, marginBottom: 6 }}>
                <div className="icon-tile" style={{ background: "linear-gradient(140deg,#67e8f9,#0e7490)" }}>
                  <MoonStar size={22} />
                </div>
                <h3 className="h-3">Анализ взаимосвязи</h3>
              </div>
              <p className="body-t" style={{ fontSize: 14.5 }}>{insight}</p>
            </Card>

            <Card
              pressable={!premium}
              onClick={premium ? undefined : () => openPaywall("sleep")}
              style={premium ? undefined : { borderStyle: "dashed" as const }}
            >
              <div className="between">
                <div className="row">
                  <div className="icon-tile" style={{ background: "linear-gradient(140deg,#fcd34d,#e07a5f)" }}>
                    <Sparkles size={22} />
                  </div>
                  <div>
                    <h3 className="h-3">Паттерны за 30 дней</h3>
                    <p className="small">{premium ? "Скоро: расширенная аналитика связей" : "Детальная аналитика — в Premium"}</p>
                  </div>
                </div>
                {!premium && <span className="lock-badge">Premium</span>}
              </div>
            </Card>
          </>
        )}
      </div>
    </div>
  );
}

export function TodayEmptyHint() {
  return <EmptyState icon={<Wrench size={26} />} title="Здесь появится твой день" />;
}
