"use client";

import React, { useMemo, useState } from "react";
import { ArrowRight, CalendarClock, ChevronLeft, Crosshair, HeartHandshake, PhoneCall } from "lucide-react";
import {
  ANSWER_LABELS,
  HELPLINE,
  NORM_TEXT,
  PLAN_LIBRARY,
  QUESTIONS,
  RESULT_TEXTS,
  VALUES,
} from "@/lib/data";
import { useApp } from "@/lib/store";
import { Btn, BrandMark, Chip, LevelLegend, Progress, RadarTest, TopBar, Card } from "@/components/ui";

// ───────────────────────── Обложка теста ─────────────────────────

export function TestCover() {
  const { flowGo, flowBack, flow } = useApp();
  return (
    <div className="screen" style={{ background: "linear-gradient(180deg,#eaf6fa 0%, #f2f7f9 40%)" }}>
      {flow.length > 1 && <TopBar onBack={flowBack} />}
      <div className="screen-pad" style={{ paddingTop: flow.length > 1 ? 6 : 70 }}>
        <div className="anim-in">
          <div
            style={{
              height: 210,
              borderRadius: 30,
              background: "linear-gradient(150deg, #0b5d74 0%, #0e7490 50%, #06b6d4 100%)",
              position: "relative",
              overflow: "hidden",
              padding: "22px 22px",
              color: "#eafafe",
              boxShadow: "0 30px 55px -24px rgba(8, 95, 120, 0.65)",
              marginBottom: 26,
            }}
          >
            <svg aria-hidden viewBox="0 0 330 210" preserveAspectRatio="none" style={{ position: "absolute", inset: 0, width: "100%", height: "100%" }}>
              <path d="M0 130 C 55 95, 105 175, 165 135 S 275 85, 330 128 L330 210 L0 210 Z" fill="rgba(255,255,255,0.16)">
                <animateTransform attributeName="transform" type="translate" values="0 0;-12 7;0 0" dur="6.5s" repeatCount="indefinite" />
              </path>
              <path d="M0 165 C 65 130, 125 200, 195 162 S 285 122, 330 160 L330 210 L0 210 Z" fill="rgba(255,255,255,0.12)">
                <animateTransform attributeName="transform" type="translate" values="0 0;12 -6;0 0" dur="9s" repeatCount="indefinite" />
              </path>
            </svg>
            <div style={{ position: "relative" }}>
              <div className="row" style={{ gap: 10 }}>
                <BrandMark size={38} />
                <span style={{ fontWeight: 700, fontSize: 15, letterSpacing: "0.01em" }}>На волне</span>
              </div>
              <h1 style={{ position: "relative", margin: "18px 0 0", fontSize: 21, lineHeight: 1.28, fontWeight: 700, letterSpacing: "-0.01em" }}>
                Пройдите научный тест и получите персональный план борьбы с выгоранием
              </h1>
            </div>
          </div>

          <p className="body-t" style={{ marginBottom: 14 }}>
            Данный тест поможет оценить ваше текущее состояние по ключевым параметрам благополучия. Оцените, насколько
            каждое из утверждений соответствует вашим ощущениям за последние 2 недели.
          </p>
          <p className="body-t" style={{ marginBottom: 26 }}>
            <b>Важно:</b> Результат — это не диагноз, а «карта» для построения персонального маршрута к лучшему
            состоянию. Все данные конфиденциальны.
          </p>

          <Btn full size="lg" onClick={() => flowGo("testQ")}>
            Пройти тест <ArrowRight size={18} />
          </Btn>
        </div>
      </div>
    </div>
  );
}

// ───────────────────────── Экран вопроса ─────────────────────────

export function TestQuestion() {
  const { state, answerQuestion, backQuestion } = useApp();
  const [picked, setPicked] = useState<number | null>(null);
  const idx = state.testDraft.length; // текущий вопрос = сколько уже отвечено
  const q = QUESTIONS[Math.min(idx, QUESTIONS.length - 1)];
  const progress = ((idx + (picked !== null ? 1 : 0)) / QUESTIONS.length) * 100;

  const pick = (v: number) => {
    if (picked !== null) return;
    setPicked(v);
    setTimeout(() => {
      setPicked(null);
      answerQuestion(v);
    }, 260);
  };

  return (
    <div className="screen">
      <div className="screen-pad" style={{ paddingTop: 62 }}>
        <div className="between" style={{ marginBottom: 14 }}>
          <button className="back-btn" onClick={backQuestion} aria-label="Назад">
            <ChevronLeft size={20} />
          </button>
          <span className="small" style={{ fontWeight: 650 }}>
            Вопрос {idx + 1} из {QUESTIONS.length}
          </span>
        </div>
        <Progress value={progress} />

        <div key={idx} className="anim-in" style={{ marginTop: 28 }}>
          <h2 className="h-2" style={{ lineHeight: 1.4, marginBottom: 26, minHeight: 88 }}>
            {q.text}
          </h2>
          <div className="stagger" style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            {ANSWER_LABELS.map((label, v) => (
              <button key={label} className={`answer-btn ${picked === v ? "picked" : ""}`} onClick={() => pick(v)}>
                <span className="a-dot" />
                {label}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// ───────────────────────── Экран результата ─────────────────────────

export function TestResult() {
  const { state, flowReset, flowGo } = useApp();
  const result = state.result;

  const content = useMemo(() => {
    if (!result) return null;
    if (result.word === "Норма") return NORM_TEXT;
    const leader = result.leader;
    if (!leader) return NORM_TEXT;
    return RESULT_TEXTS[leader][result.scales[leader].level];
  }, [result]);

  if (!result || !content) {
    return (
      <div className="screen">
        <div className="screen-pad">
          <Card>
            <p className="body-t">Результат не найден. Пройди тест заново, чтобы получить свой план.</p>
            <div style={{ height: 14 }} />
            <Btn full onClick={() => flowReset("testCover")}>Пройти тест</Btn>
          </Card>
        </div>
      </div>
    );
  }

  const hasSevere = (Object.values(result.scales) as { level: string }[]).some((s) => s.level === "severe");

  return (
    <div className="screen">
      <div className="screen-pad anim-in" style={{ paddingTop: 66, textAlign: "center" }}>
        <Card style={{ padding: "20px 8px 12px", marginBottom: 22 }}>
          <RadarTest scales={result.scales} />
          <LevelLegend scales={result.scales} />
        </Card>

        <h1 className="h-display anim-in" style={{ animationDelay: "0.15s", marginBottom: 14 }}>
          {result.word}
        </h1>
        <p className="body-t anim-in" style={{ animationDelay: "0.25s", textAlign: "center" }}>
          {content}
        </p>

        <div style={{ height: 28 }} />
        <Btn full size="lg" onClick={() => flowGo("plan")}>
          Получить персональный план <ArrowRight size={18} />
        </Btn>

        <p className="tiny" style={{ marginTop: 22 }}>
          Тест не является медицинским диагнозом.
        </p>
        {hasSevere && (
          <p className="tiny" style={{ marginTop: 8 }}>
            Если сейчас совсем тяжело: <b>{HELPLINE.phone}</b> — {HELPLINE.label.toLowerCase()}.
          </p>
        )}
      </div>
    </div>
  );
}

// ───────────────────────── Персональный план ─────────────────────────

export function Plan() {
  const { state, leaderKey, planSteps, update, toast } = useApp();
  const [value, setValue] = useState<string | null>(state.planValue);
  const plan = PLAN_LIBRARY[state.result ? leaderKey : "norm"];
  const firstDaySteps = planSteps.slice(0, 3);

  const begin = () => {
    update({ onboarded: true, planValue: value });
    toast("План создан. Начинаем день 1 из 21");
  };

  return (
    <div className="screen" style={{ background: "#f2f7f9" }}>
      <div className="screen-pad" style={{ paddingTop: 62 }}>
        <div className="anim-in">
          <p className="eyebrow">Твой персональный план</p>
          <h1 className="h-1" style={{ marginBottom: 10 }}>День 1 из 21</h1>
          <p className="body-t" style={{ marginBottom: 20 }}>{plan.goal}.</p>
        </div>

        <Card className="anim-in" style={{ animationDelay: "0.08s", marginBottom: 16 }}>
          <div className="row" style={{ gap: 10, marginBottom: 6 }}>
            <div className="icon-tile" style={{ background: "linear-gradient(140deg,#22d3ee,#0e7490)" }}>
              <Crosshair size={22} />
            </div>
            <div>
              <p className="tiny" style={{ margin: 0 }}>Фокус программы</p>
              <h3 className="h-3">{plan.focus}</h3>
            </div>
            <div style={{ marginLeft: "auto" }}>
              <span className="chip" style={{ minHeight: 32, cursor: "default", background: "rgba(6,182,212,0.1)", border: "none", color: "#0e7490" }}>
                <CalendarClock size={14} /> 21 день
              </span>
            </div>
          </div>
          <p className="small" style={{ marginTop: 8 }}>
            Маленькие шаги каждый день. Через 21 день — повторный тест и видимый прогресс.
          </p>
        </Card>

        <Card className="anim-in" style={{ animationDelay: "0.14s", marginBottom: 16 }}>
          <div className="row" style={{ gap: 10, marginBottom: 8 }}>
            <div className="icon-tile" style={{ background: "linear-gradient(140deg,#fbbf24,#e07a5f)" }}>
              <HeartHandshake size={22} />
            </div>
            <h3 className="h-3">Ради чего эти 21 день?</h3>
          </div>
          <p className="small" style={{ marginBottom: 12 }}>План крепче, когда у него есть «зачем». Выбери, что важнее всего сейчас:</p>
          <div className="row" style={{ flexWrap: "wrap", gap: 8 }}>
            {VALUES.map((v) => (
              <Chip key={v} active={value === v} onClick={() => setValue(value === v ? null : v)}>
                {v}
              </Chip>
            ))}
          </div>
        </Card>

        <Card className="anim-in" style={{ animationDelay: "0.2s", marginBottom: 22 }}>
          <p className="tiny" style={{ marginBottom: 10, fontWeight: 700, letterSpacing: "0.08em", textTransform: "uppercase" }}>
            Шаги на сегодня
          </p>
          {firstDaySteps.map((s) => (
            <div key={s} className="row" style={{ gap: 10, padding: "8px 0", alignItems: "flex-start" }}>
              <span
                style={{
                  width: 22,
                  height: 22,
                  borderRadius: 8,
                  border: "2px solid rgba(14,116,144,0.4)",
                  flexShrink: 0,
                  marginTop: 1,
                }}
              />
              <span className="body-t" style={{ fontSize: 14.5 }}>{s}</span>
            </div>
          ))}
          <p className="tiny" style={{ marginTop: 10 }}>и ещё {planSteps.length - firstDaySteps.length} шаг(а) появится на экране «Сегодня»</p>
        </Card>

        <div className="anim-in" style={{ animationDelay: "0.26s" }}>
          <Btn full size="lg" onClick={begin}>
            Начать день 1 <ArrowRight size={18} />
          </Btn>
          <p className="tiny" style={{ textAlign: "center", marginTop: 14 }}>
            <PhoneCall size={11} style={{ verticalAlign: -1, marginRight: 4 }} />
            План обновляется каждое утро. SOS-режим доступен всегда — кнопка в центре внизу.
          </p>
        </div>
      </div>
    </div>
  );
}
