"use client";

import React, { useState } from "react";
import { BrainCircuit, CalendarHeart, ListOrdered, NotebookPen, Sparkles } from "lucide-react";
import { GRATITUDE_PLACEHOLDERS, MOOD_LABELS } from "@/lib/data";
import { useApp } from "@/lib/store";
import { Btn, Card, CardSkeleton, EmptyState, TopBar, useFakeLoad } from "@/components/ui";

type DiaryTab = "new" | "list" | "gratitude";

export function Diary() {
  const { back, chartWeek } = useApp();
  const loading = useFakeLoad(380);
  const [tab, setTab] = useState<DiaryTab>("new");

  return (
    <div className="screen">
      <TopBar title="Дневник мыслей" onBack={back} />
      <div style={{ padding: "6px 20px 12px" }}>
        <div className="seg">
          <button className={tab === "new" ? "active" : ""} onClick={() => setTab("new")}>
            <span className="row" style={{ justifyContent: "center", gap: 6 }}><NotebookPen size={14} /> Запись</span>
          </button>
          <button className={tab === "list" ? "active" : ""} onClick={() => setTab("list")}>
            <span className="row" style={{ justifyContent: "center", gap: 6 }}><ListOrdered size={14} /> Записи</span>
          </button>
          <button className={tab === "gratitude" ? "active" : ""} onClick={() => setTab("gratitude")}>
            <span className="row" style={{ justifyContent: "center", gap: 6 }}><CalendarHeart size={14} /> Благодарность</span>
          </button>
        </div>
      </div>
      <div className="screen-pad" style={{ paddingTop: 2 }}>
        {loading ? (
          <>
            <CardSkeleton lines={3} />
            <div style={{ height: 12 }} />
            <CardSkeleton lines={3} />
          </>
        ) : tab === "new" ? (
          <CbtForm key="f" />
        ) : tab === "list" ? (
          <DiaryList />
        ) : (
          <GratitudeTab />
        )}

        {tab === "list" && (
          <>
            <div style={{ height: 14 }} />
            <MoodGrid chartWeek={chartWeek} />
          </>
        )}
      </div>
    </div>
  );
}

// ───────────────────────── КПТ: разбор мысли ─────────────────────────

function CbtForm() {
  const { addDiary, toast } = useApp();
  const [situation, setSituation] = useState("");
  const [thought, setThought] = useState("");
  const [emotion, setEmotion] = useState(60);
  const [support, setSupport] = useState("");
  const [against, setAgainst] = useState("");
  const [balanced, setBalanced] = useState("");
  const [faithAfter, setFaithAfter] = useState(30);
  const [err, setErr] = useState("");

  const save = () => {
    if (!situation.trim() || !thought.trim()) {
      setErr("Заполни хотя бы ситуацию и мысль — остальное можно пропустить");
      return;
    }
    addDiary({
      situation: situation.trim(),
      thought: thought.trim(),
      emotion,
      support: support.trim(),
      against: against.trim(),
      balanced: balanced.trim(),
      faithBefore: emotion,
      faithAfter,
    });
    toast("Запись сохранена. Вера в мысль пересмотрена");
    setSituation(""); setThought(""); setSupport(""); setAgainst(""); setBalanced("");
    setEmotion(60); setFaithAfter(30); setErr("");
  };

  return (
    <div className="anim-in" style={{ display: "flex", flexDirection: "column", gap: 14 }}>
      <div className="notice">
        <BrainCircuit size={16} style={{ flexShrink: 0, marginTop: 1, color: "#0e7490" }} />
        <span>Ядро КПТ: мысль влияет, пока звучит как факт. Разберём её по шагам — 2 минуты.</span>
      </div>

      <Card>
        <label className="label" htmlFor="d-sit">1. Ситуация</label>
        <textarea id="d-sit" className="textarea" style={{ minHeight: 64 }} placeholder="Что произошло? Где, с кем?" value={situation} onChange={(e) => setSituation(e.target.value)} />

        <div style={{ height: 12 }} />
        <label className="label" htmlFor="d-th">2. Автоматическая мысль</label>
        <textarea id="d-th" className="textarea" style={{ minHeight: 64 }} placeholder="Запиши мысль точно, как она прозвучала в голове" value={thought} onChange={(e) => setThought(e.target.value)} />

        <div style={{ height: 12 }} />
        <div className="between" style={{ marginBottom: 6 }}>
          <span className="label" style={{ margin: 0 }}>3. Сила эмоции</span>
          <b style={{ color: "#0e7490", fontSize: 14 }}>{emotion}/100</b>
        </div>
        <input type="range" min={0} max={100} value={emotion} onChange={(e) => setEmotion(Number(e.target.value))} className="slider" aria-label="Сила эмоции" />
      </Card>

      <Card>
        <label className="label" htmlFor="d-sup">4. Что говорит «за» мысль?</label>
        <textarea id="d-sup" className="textarea" style={{ minHeight: 56 }} placeholder="Факты, которые её поддерживают" value={support} onChange={(e) => setSupport(e.target.value)} />
        <div style={{ height: 12 }} />
        <label className="label" htmlFor="d-against">5. Что говорит «против»?</label>
        <textarea id="d-against" className="textarea" style={{ minHeight: 56 }} placeholder="Факты, которые она игнорирует" value={against} onChange={(e) => setAgainst(e.target.value)} />
      </Card>

      <Card>
        <p className="tiny" style={{ marginBottom: 8, fontWeight: 700, letterSpacing: "0.06em", textTransform: "uppercase", color: "#0f766e" }}>
          Расцепление: это просто мысль, а не правда
        </p>
        <label className="label" htmlFor="d-bal">6. Сбалансированная мысль</label>
        <textarea
          id="d-bal"
          className="textarea"
          style={{ minHeight: 64 }}
          placeholder="«У меня есть мысль, что… При этом факты говорят…»"
          value={balanced}
          onChange={(e) => setBalanced(e.target.value)}
        />
        <div style={{ height: 12 }} />
        <div className="between" style={{ marginBottom: 6 }}>
          <span className="label" style={{ margin: 0 }}>Вера в исходную мысль теперь</span>
          <b style={{ color: "#0e9f6e", fontSize: 14 }}>{faithAfter}/100</b>
        </div>
        <input type="range" min={0} max={100} value={faithAfter} onChange={(e) => setFaithAfter(Number(e.target.value))} className="slider" aria-label="Вера в мысль после разбора" />
      </Card>

      {err && <p className="field-error">{err}</p>}
      <Btn full size="lg" onClick={save}>Сохранить запись</Btn>
    </div>
  );
}

// ───────────────────────── Список записей ─────────────────────────

function DiaryList() {
  const { state } = useApp();
  if (state.diary.length === 0) {
    return (
      <EmptyState
        icon={<NotebookPen size={26} />}
        title="Записей пока нет"
        text="Первый разбор мысли — за 2 минуты во вкладке «Запись»"
      />
    );
  }
  return (
    <div className="stagger" style={{ display: "flex", flexDirection: "column", gap: 12 }}>
      {state.diary.map((d) => (
        <Card key={d.id}>
          <div className="between" style={{ marginBottom: 6 }}>
            <span className="tiny" style={{ fontWeight: 700 }}>{formatDay(d.day)}</span>
            <span className="chip" style={{ minHeight: 26, cursor: "default", fontSize: 11, background: "rgba(6,182,212,0.1)", border: "none", color: "#0e7490" }}>
              вера: {d.faithBefore} → {d.faithAfter}
            </span>
          </div>
          <p className="body-t" style={{ fontSize: 14.5, marginBottom: 4 }}><b>Мысль:</b> {d.thought}</p>
          <p className="small">{d.situation}</p>
          {d.balanced && (
            <p className="small" style={{ marginTop: 8, paddingTop: 8, borderTop: "1px dashed rgba(13,36,48,0.12)" }}>
              <Sparkles size={12} style={{ verticalAlign: -2, marginRight: 4, color: "#0f766e" }} />
              {d.balanced}
            </p>
          )}
        </Card>
      ))}
    </div>
  );
}

function formatDay(key: string): string {
  try {
    const [y, m, d] = key.split("-").map(Number);
    return new Intl.DateTimeFormat("ru-RU", { day: "numeric", month: "long" }).format(new Date(y, m - 1, d));
  } catch {
    return key;
  }
}

// ───────────────────────── Сетка настроения и привычек ─────────────────────────

function MoodGrid({ chartWeek }: { chartWeek: { label: string; mood: number | null; sleep: number | null; day: string }[] }) {
  return (
    <Card>
      <h3 className="h-3" style={{ marginBottom: 10 }}>Сетка настроения · 7 дней</h3>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(7, 1fr)", gap: 6 }}>
        {chartWeek.map((d) => (
          <div key={d.day} style={{ textAlign: "center" }}>
            <div
              title={d.mood ? MOOD_LABELS[d.mood - 1] : "нет данных"}
              style={{
                height: 42,
                borderRadius: 10,
                background:
                  d.mood === null
                    ? "rgba(13,36,48,0.05)"
                    : d.mood <= 2
                      ? "rgba(249,115,115,0.28)"
                      : d.mood === 3
                        ? "rgba(251,191,36,0.3)"
                        : "rgba(52,211,153,0.35)",
                display: "grid",
                placeItems: "center",
                fontSize: 11,
                fontWeight: 700,
                color: "rgba(13,36,48,0.6)",
              }}
            >
              {d.mood ?? "·"}
            </div>
            <span className="tiny" style={{ fontSize: 10 }}>{d.label}</span>
          </div>
        ))}
      </div>
      <p className="tiny" style={{ marginTop: 10 }}>Числа — настроение (1–5) по чек-инам. Цвет без агрессивного красного: пастель и только подсказки.</p>
    </Card>
  );
}

// ───────────────────────── Благодарность ─────────────────────────

function GratitudeTab() {
  const { state, todayKey, addGratitude, toast } = useApp();
  const existing = state.gratitudes.find((g) => g.day === todayKey);
  const [items, setItems] = useState<string[]>(existing?.items ?? ["", "", ""]);

  const save = () => {
    const filled = items.map((s) => s.trim()).filter(Boolean);
    if (filled.length === 0) {
      toast("Напиши хотя бы один момент");
      return;
    }
    addGratitude(filled);
    toast("Благодарность записана");
  };

  return (
    <div className="anim-in" style={{ display: "flex", flexDirection: "column", gap: 14 }}>
      <Card>
        <h3 className="h-3" style={{ marginBottom: 6 }}>Три хороших момента дня</h3>
        <p className="small" style={{ marginBottom: 14 }}>
          Регулярность важнее объёма: 2–3 раза в неделю достаточно, чтобы внимание перестроилось на опоры.
        </p>
        {items.map((v, i) => (
          <div key={i} style={{ marginBottom: 10 }}>
            <input
              className="input"
              placeholder={GRATITUDE_PLACEHOLDERS[i] ?? "Момент дня"}
              value={v}
              onChange={(e) => setItems((arr) => arr.map((x, j) => (j === i ? e.target.value : x)))}
              aria-label={`Момент ${i + 1}`}
            />
          </div>
        ))}
        <Btn full onClick={save}>Сохранить</Btn>
      </Card>

      {state.gratitudes.filter((g) => g.day !== todayKey).length > 0 && (
        <Card>
          <h3 className="h-3" style={{ marginBottom: 10 }}>Недавние записи</h3>
          {state.gratitudes
            .filter((g) => g.day !== todayKey)
            .slice(0, 3)
            .map((g) => (
              <div key={g.day} style={{ padding: "8px 0", borderBottom: "1px dashed rgba(13,36,48,0.1)" }}>
                <p className="tiny" style={{ fontWeight: 700, marginBottom: 4 }}>{formatDay(g.day)}</p>
                {g.items.map((it, i) => (
                  <p key={i} className="small" style={{ marginBottom: 2 }}>
                    • {it}
                  </p>
                ))}
              </div>
            ))}
        </Card>
      )}
    </div>
  );
}
