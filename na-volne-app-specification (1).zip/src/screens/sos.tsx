"use client";

import React, { useEffect, useRef, useState } from "react";
import {
  Anchor,
  Check,
  Heart,
  MessagesSquare,
  PhoneCall,
  Waves,
  Wind,
  X,
} from "lucide-react";
import { HELPLINE, SOS_DIALOG } from "@/lib/data";
import { useApp } from "@/lib/store";
import { Btn } from "@/components/ui";

function SosHeader({ title, sub }: { title: string; sub?: string }) {
  const { sosBack, sos, closeSos } = useApp();
  const canBack = (sos?.length ?? 1) > 1;
  return (
    <div className="between" style={{ padding: "58px 20px 0", position: "relative", zIndex: 3 }}>
      <div>
        <h1 style={{ fontSize: 22, fontWeight: 700, margin: 0, letterSpacing: "-0.01em" }}>{title}</h1>
        {sub && <p style={{ margin: "4px 0 0", fontSize: 13.5, color: "rgba(233,245,249,0.66)" }}>{sub}</p>}
      </div>
      <button
        onClick={canBack ? sosBack : closeSos}
        aria-label={canBack ? "Назад" : "Закрыть SOS"}
        className="back-btn on-dark"
        style={{ width: 44, height: 44 }}
      >
        {canBack ? (
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="m15 18-6-6 6-6" /></svg>
        ) : (
          <X size={20} />
        )}
      </button>
    </div>
  );
}

// ───────────────────────── SOS: меню ─────────────────────────

export function SosMenu() {
  const { sosGo } = useApp();
  return (
    <div className="sos-theme" style={{ position: "absolute", inset: 0, overflowY: "auto" }}>
      <SosHeader title="Ты в безопасности" sub="Поддержка рядом. Работает без сети" />
      <div style={{ padding: "22px 20px 40px" }}>
        <p style={{ fontSize: 15, lineHeight: 1.6, color: "rgba(233,245,249,0.85)", margin: "0 0 22px" }}>
          Выбери то, что откликается прямо сейчас. Никакой спешки — я подожду.
        </p>
        <div className="stagger" style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          <button className="sos-card" onClick={() => sosGo("sosBreathe")}>
            <span className="icon-tile" style={{ background: "linear-gradient(140deg,#67e8f9,#0e7490)" }}>
              <Wind size={22} />
            </span>
            <span style={{ flex: 1 }}>
              <b style={{ display: "block", fontSize: 16 }}>Дыхание 4-7-8</b>
              <span style={{ fontSize: 13, color: "rgba(233,245,249,0.66)" }}>3 цикла — снизить накал за две минуты</span>
            </span>
          </button>

          <button className="sos-card" onClick={() => sosGo("sosDialog")}>
            <span className="icon-tile" style={{ background: "linear-gradient(140deg,#f9a8d4,#e07a5f)" }}>
              <MessagesSquare size={22} />
            </span>
            <span style={{ flex: 1 }}>
              <b style={{ display: "block", fontSize: 16 }}>Короткий диалог</b>
              <span style={{ fontSize: 13, color: "rgba(233,245,249,0.66)" }}>Разберём, что происходит, шаг за шагом</span>
            </span>
          </button>

          <button className="sos-card" onClick={() => sosGo("sosGrounding")}>
            <span className="icon-tile" style={{ background: "linear-gradient(140deg,#5eead4,#0f766e)" }}>
              <Anchor size={22} />
            </span>
            <span style={{ flex: 1 }}>
              <b style={{ display: "block", fontSize: 16 }}>Заземление 5-4-3-2-1</b>
              <span style={{ fontSize: 13, color: "rgba(233,245,249,0.66)" }}>Скорая техника — вернуться в «здесь и сейчас»</span>
            </span>
          </button>

          <a
            href={`tel:${HELPLINE.phone.replace(/[^+\d]/g, "")}`}
            className="sos-card"
            style={{ textDecoration: "none" }}
          >
            <span className="icon-tile" style={{ background: "linear-gradient(140deg,#fcd34d,#e07a5f)" }}>
              <PhoneCall size={22} />
            </span>
            <span style={{ flex: 1 }}>
              <b style={{ display: "block", fontSize: 16 }}>{HELPLINE.phone}</b>
              <span style={{ fontSize: 13, color: "rgba(233,245,249,0.66)" }}>{HELPLINE.label}. {HELPLINE.region}</span>
            </span>
          </a>
        </div>

        <p style={{ textAlign: "center", marginTop: 26, fontSize: 12.5, color: "rgba(233,245,249,0.5)" }}>
          Если есть риск причинения вреда — сразу звони 112
        </p>
      </div>
    </div>
  );
}

// ───────────────────────── SOS: дыхание 4-7-8 ─────────────────────────

const PHASES = [
  { name: "Вдох", hint: "через нос", sec: 4, scale: 1.34 },
  { name: "Задержка", hint: "мягко, без напряжения", sec: 7, scale: 1.34 },
  { name: "Выдох", hint: "медленно, через рот", sec: 8, scale: 1 },
];

export function SosBreathe() {
  const { closeSos, toast } = useApp();
  // Одна «ось времени» в секундах; фаза, счётчик и цикл выводятся из неё.
  const CYCLE_SEC = 19; // 4 + 7 + 8
  const TOTAL = CYCLE_SEC * 3;
  const [t, setT] = useState(0);
  const done = t >= TOTAL;
  const inCycle = t % CYCLE_SEC;
  const phaseIdx = inCycle < 4 ? 0 : inCycle < 11 ? 1 : 2;
  const phase = PHASES[phaseIdx];
  const count = phaseIdx === 0 ? 4 - inCycle : phaseIdx === 1 ? 11 - inCycle : 19 - inCycle;
  const cycle = Math.min(3, Math.floor(t / CYCLE_SEC) + 1);

  useEffect(() => {
    if (done) return;
    const id = setInterval(() => setT((x) => x + 1), 1000);
    return () => clearInterval(id);
  }, [done]);

  if (done) {
    return (
      <div className="sos-theme" style={{ position: "absolute", inset: 0 }}>
        <SosHeader title="Дыхание 4-7-8" />
        <div style={{ display: "grid", placeItems: "center", padding: "60px 24px", textAlign: "center" }}>
          <div
            style={{
              width: 88,
              height: 88,
              borderRadius: "50%",
              display: "grid",
              placeItems: "center",
              background: "radial-gradient(circle at 35% 30%, #34d399, #0e9f6e)",
              color: "#fff",
              animation: "popIn .45s var(--ease-out) both",
              marginBottom: 18,
            }}
          >
            <Check size={40} strokeWidth={3} />
          </div>
          <h2 style={{ fontSize: 24, fontWeight: 700, margin: "0 0 8px" }}>Три цикла позади</h2>
          <p style={{ color: "rgba(233,245,249,0.75)", fontSize: 14.5, lineHeight: 1.55, maxWidth: 260, margin: "0 0 26px" }}>
            Нервная система получила сигнал «можно расслабиться». Заметь, как изменилось тело.
          </p>
          <div style={{ display: "flex", gap: 10, flexWrap: "wrap", justifyContent: "center" }}>
            <Btn variant="white" onClick={() => setT(0)}>
              Ещё три цикла
            </Btn>
            <Btn variant="coral" onClick={() => { toast("Хорошо подышали"); closeSos(); }}>Готово</Btn>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="sos-theme" style={{ position: "absolute", inset: 0 }}>
      <SosHeader title="Дыхание 4-7-8" sub={`Цикл ${cycle} из 3`} />

      <div style={{ display: "grid", placeItems: "center", padding: "46px 20px 0" }}>
        <div style={{ position: "relative", animation: "popIn .4s var(--ease-out) both" }}>
          <span className="breathe-halo" />
          <div
            className="breathe-orb"
            style={{
              transform: `scale(${phase.scale})`,
              transitionDuration: `${phase.sec}s`,
              transitionTimingFunction: phaseIdx === 1 ? "ease" : "ease-in-out",
            }}
          >
            <div style={{ textAlign: "center", color: "#062b38" }}>
              <div style={{ fontSize: 15, fontWeight: 800, letterSpacing: "0.12em", textTransform: "uppercase", opacity: 0.75 }}>
                {phase.name}
              </div>
              <div style={{ fontSize: 52, fontWeight: 800, fontVariantNumeric: "tabular-nums", lineHeight: 1.05 }}>
                {count}
              </div>
            </div>
          </div>
        </div>
        <p style={{ marginTop: 46, fontSize: 14.5, color: "rgba(233,245,249,0.72)" }}>{phase.hint}</p>
      </div>

      <div style={{ position: "absolute", bottom: 34, left: 0, right: 0, display: "flex", justifyContent: "center", gap: 8 }}>
        {[1, 2, 3].map((c) => (
          <span
            key={c}
            style={{
              width: 10,
              height: 10,
              borderRadius: "50%",
              background: c < cycle ? "#5eead4" : c === cycle ? "#f9a8d4" : "rgba(255,255,255,0.2)",
              transition: "background .3s",
            }}
          />
        ))}
      </div>
    </div>
  );
}

// ───────────────────────── SOS: диалог ─────────────────────────

interface ChatMsg {
  id: number;
  mine: boolean;
  text: string;
  hotline?: boolean;
}

export function SosDialog() {
  const { sosGo, closeSos } = useApp();
  const [nodeId, setNodeId] = useState("start");
  const [msgs, setMsgs] = useState<ChatMsg[]>([]);
  const [typing, setTyping] = useState(false);
  const [ready, setReady] = useState(false);
  const idRef = useRef(1);
  const listRef = useRef<HTMLDivElement>(null);
  const node = SOS_DIALOG[nodeId];

  // появление сообщений узла с «печатанием»
  useEffect(() => {
    let cancelled = false;
    setTyping(true);
    setReady(false);
    const queue = [...node.messages];
    let delay = nodeId === "start" ? 350 : 750;
    queue.forEach((m) => {
      setTimeout(() => {
        if (cancelled) return;
        setMsgs((mm) => [...mm, { id: idRef.current++, mine: false, text: m }]);
      }, delay);
      delay += m.length * 12 + 620;
    });
    setTimeout(() => {
      if (cancelled) return;
      setTyping(false);
      setReady(true);
    }, delay - 300);
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [nodeId]);

  // стартовый набор при монтировании
  useEffect(() => {
    setMsgs([]);
    idRef.current = 1;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    listRef.current?.scrollTo({ top: 99999, behavior: "smooth" });
  }, [msgs, typing, ready]);

  const choose = (opt: { label: string; next?: string; action?: "breathe" | "grounding" | "hotline" | "close" }) => {
    setMsgs((mm) => [...mm, { id: idRef.current++, mine: true, text: opt.label }]);
    setReady(false);
    if (opt.next) {
      setTimeout(() => setNodeId(opt.next!), 420);
      return;
    }
    setTimeout(() => {
      if (opt.action === "breathe") sosGo("sosBreathe");
      else if (opt.action === "grounding") sosGo("sosGrounding");
      else if (opt.action === "close") closeSos();
      else if (opt.action === "hotline") {
        setMsgs((mm) => [
          ...mm,
          {
            id: idRef.current++,
            mine: false,
            text: `Телефон доверия: ${HELPLINE.phone}`,
            hotline: true,
          },
        ]);
        setReady(true);
      }
    }, 420);
  };

  return (
    <div className="sos-theme" style={{ position: "absolute", inset: 0, display: "flex", flexDirection: "column" }}>
      <SosHeader title="Я рядом" sub="Бережный диалог поддержки" />
      <div ref={listRef} style={{ flex: 1, overflowY: "auto", padding: "20px 20px 10px", scrollbarWidth: "none" }}>
        {msgs.map((m) =>
          m.hotline ? (
            <div className="chat-row" key={m.id}>
              <span className="chat-ava"><Waves size={16} /></span>
              <div className="chat-bubble" style={{ width: "100%" }}>
                <p style={{ margin: "0 0 8px", fontSize: 14 }}>Живая поддержка, бесплатно и круглосуточно:</p>
                <a
                  href={`tel:${HELPLINE.phone.replace(/[^+\d]/g, "")}`}
                  className="row"
                  style={{ gap: 8, color: "#5eead4", fontWeight: 800, fontSize: 18, textDecoration: "none", minHeight: 44 }}
                >
                  <PhoneCall size={18} /> {HELPLINE.phone}
                </a>
                <p style={{ margin: "8px 0 0", fontSize: 12, color: "rgba(233,245,249,0.6)" }}>{HELPLINE.region}</p>
              </div>
            </div>
          ) : m.mine ? (
            <div className="chat-row" key={m.id} style={{ justifyContent: "flex-end" }}>
              <div className="chat-bubble mine">{m.text}</div>
            </div>
          ) : (
            <div className="chat-row" key={m.id}>
              <span className="chat-ava"><Waves size={16} /></span>
              <div className="chat-bubble">{m.text}</div>
            </div>
          )
        )}
        {typing && (
          <div className="chat-row">
            <span className="chat-ava"><Waves size={16} /></span>
            <div className="chat-bubble" style={{ padding: "10px 16px" }}>
              <span className="typing-dots"><i /><i /><i /></span>
            </div>
          </div>
        )}
      </div>
      <div style={{ padding: "10px 16px 28px", display: "flex", flexDirection: "column", gap: 8 }}>
        {ready &&
          node.options.map((o) => (
            <button
              key={o.label}
              className="sos-card"
              style={{ padding: "13px 16px", minHeight: 48 }}
              onClick={() => choose(o)}
            >
              <b style={{ fontSize: 14.5 }}>{o.label}</b>
            </button>
          ))}
        {!ready && <p style={{ textAlign: "center", fontSize: 12.5, color: "rgba(233,245,249,0.5)", margin: 6 }}>…</p>}
      </div>
    </div>
  );
}

// ───────────────────────── SOS: заземление 5-4-3-2-1 ─────────────────────────

const GROUND_STEPS = [
  { count: 5, label: "5 вещей, которые видишь", hint: "Назови их про себя и отмечай — по одной" },
  { count: 4, label: "4 звука, которые слышишь", hint: "Даже тихие: дорога, дыхание, часы" },
  { count: 3, label: "3 вещи, которые чувствуешь телом", hint: "Опора стоп, ткань одежды, прохлада воздуха" },
  { count: 2, label: "2 запаха вокруг", hint: "Или любимые запахи, которые можешь вспомнить" },
  { count: 1, label: "1 вкус", hint: "Сглотни, почувствуй вкус во рту. Ты здесь" },
];

export function SosGrounding() {
  const { closeSos, toast } = useApp();
  const [step, setStep] = useState(0);
  const [hits, setHits] = useState(0);
  const [done, setDone] = useState(false);
  const s = GROUND_STEPS[step];

  const tap = () => {
    const next = hits + 1;
    if (next >= s.count) {
      if (step === GROUND_STEPS.length - 1) {
        setDone(true);
      } else {
        setStep(step + 1);
        setHits(0);
      }
    } else {
      setHits(next);
    }
  };

  if (done) {
    return (
      <div className="sos-theme" style={{ position: "absolute", inset: 0 }}>
        <SosHeader title="Заземление" />
        <div style={{ display: "grid", placeItems: "center", padding: "70px 24px", textAlign: "center" }}>
          <div
            style={{
              width: 88,
              height: 88,
              borderRadius: "50%",
              display: "grid",
              placeItems: "center",
              background: "radial-gradient(circle at 35% 30%, #5eead4, #0f766e)",
              color: "#fff",
              animation: "popIn .45s var(--ease-out) both",
              marginBottom: 18,
            }}
          >
            <Anchor size={40} />
          </div>
          <h2 style={{ fontSize: 24, fontWeight: 700, margin: "0 0 8px" }}>Ты здесь. В настоящем</h2>
          <p style={{ color: "rgba(233,245,249,0.75)", fontSize: 14.5, lineHeight: 1.55, maxWidth: 270, margin: "0 0 26px" }}>
            Тревога живёт в «а вдруг». Ты только что вернул(а) внимание в «сейчас» — это навык, и он у тебя есть.
          </p>
          <Btn variant="coral" onClick={() => { toast("Заземление завершено"); closeSos(); }}>
            <Heart size={16} /> Мне лучше
          </Btn>
        </div>
      </div>
    );
  }

  return (
    <div className="sos-theme" style={{ position: "absolute", inset: 0 }}>
      <SosHeader title="Заземление 5-4-3-2-1" sub={`Шаг ${step + 1} из 5`} />
      <div style={{ padding: "34px 24px", textAlign: "center" }}>
        <div className="anim-in" key={step}>
          <p style={{ fontSize: 13, letterSpacing: "0.16em", textTransform: "uppercase", color: "rgba(233,245,249,0.55)", margin: "0 0 10px" }}>
            Найди и назови
          </p>
          <h2 style={{ fontSize: 24, fontWeight: 700, margin: "0 0 8px", lineHeight: 1.25 }}>{s.label}</h2>
          <p style={{ color: "rgba(233,245,249,0.68)", fontSize: 14, margin: "0 0 30px" }}>{s.hint}</p>
        </div>

        <div className="row" style={{ justifyContent: "center", gap: 12, marginBottom: 34 }}>
          {Array.from({ length: s.count }).map((_, i) => (
            <button key={i} className={`ground-count ${i < hits ? "hit" : ""}`} onClick={i === hits ? tap : undefined} aria-label={`Отметить ${i + 1}`}>
              {i < hits ? <Check size={22} /> : i + 1}
            </button>
          ))}
        </div>

        <Btn variant="outline" style={{ background: "rgba(255,255,255,0.08)", borderColor: "rgba(255,255,255,0.2)", color: "#e9f5f9" }} onClick={tap}>
          Отметить {hits + 1} из {s.count}
        </Btn>

        <div style={{ display: "flex", justifyContent: "center", gap: 8, marginTop: 34 }}>
          {GROUND_STEPS.map((_, i) => (
            <span
              key={i}
              style={{
                width: i === step ? 22 : 8,
                height: 8,
                borderRadius: 99,
                background: i < step ? "#5eead4" : i === step ? "#f9a8d4" : "rgba(255,255,255,0.2)",
                transition: "all .3s",
              }}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
