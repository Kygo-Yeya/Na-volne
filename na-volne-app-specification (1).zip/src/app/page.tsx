import AppShell from "@/components/shell";

export const dynamic = "force-dynamic";

export default function Page() {
  return <AppShell />;
}
