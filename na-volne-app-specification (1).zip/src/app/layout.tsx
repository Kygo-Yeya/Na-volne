import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "На волне — персональный план психологической устойчивости",
  description:
    "Персональный проводник в самопознании: тест выгорания, SOS-режим, карта личности, курсы и техники самопомощи. Интерактивный макет приложения.",
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
  themeColor: "#041520",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ru">
      <body>{children}</body>
    </html>
  );
}
