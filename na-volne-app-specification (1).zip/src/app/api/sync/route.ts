import { NextResponse } from "next/server";
import { db } from "@/db";
import { checkins, testResults, users } from "@/db/schema";

export const dynamic = "force-dynamic";

interface SyncBody {
  uid?: string;
  user?: { name?: string; contact?: string; isGuest?: boolean } | null;
  premium?: boolean;
  premiumPlan?: string | null;
  result?: {
    answers: number[];
    scales: Record<string, { raw: number; max: number; pct: number; level: string }>;
    flags: Record<string, boolean>;
    word: string;
    symptomIndex: number;
    resilienceIndex: number;
    completedAt: string;
  } | null;
  checkins?: { day: string; mood: number; note?: string; sleep?: number; energy?: number }[];
}

export async function POST(req: Request) {
  try {
    const body = (await req.json()) as SyncBody;
    if (!body?.uid) {
      return NextResponse.json({ ok: false, error: "uid required" }, { status: 400 });
    }

    const [user] = await db
      .insert(users)
      .values({
        anonKey: body.uid,
        name: body.user?.name ?? "Гость",
        contact: body.user?.contact ?? null,
        isGuest: body.user?.isGuest ?? true,
        premium: Boolean(body.premium),
        premiumPlan: body.premiumPlan ?? null,
        updatedAt: new Date(),
      })
      .onConflictDoUpdate({
        target: users.anonKey,
        set: {
          name: body.user?.name ?? "Гость",
          contact: body.user?.contact ?? null,
          isGuest: body.user?.isGuest ?? true,
          premium: Boolean(body.premium),
          premiumPlan: body.premiumPlan ?? null,
          updatedAt: new Date(),
        },
      })
      .returning({ id: users.id });

    if (body.result && body.result.word) {
      await db
        .insert(testResults)
        .values({
          userId: user.id,
          answers: body.result.answers ?? [],
          scales: body.result.scales ?? {},
          flags: body.result.flags ?? {},
          wordResult: body.result.word,
          symptomIndex: body.result.symptomIndex ?? 0,
          resilienceIndex: body.result.resilienceIndex ?? 0,
          completedAt: body.result.completedAt,
        })
        .onConflictDoNothing();
    }

    if (Array.isArray(body.checkins)) {
      for (const c of body.checkins.slice(0, 60)) {
        if (!c?.day || typeof c.mood !== "number") continue;
        await db
          .insert(checkins)
          .values({
            userId: user.id,
            day: c.day,
            mood: c.mood,
            note: c.note ?? null,
            sleepHours: c.sleep ?? null,
            energy: c.energy ?? null,
          })
          .onConflictDoUpdate({
            target: [checkins.userId, checkins.day],
            set: {
              mood: c.mood,
              note: c.note ?? null,
              sleepHours: c.sleep ?? null,
              energy: c.energy ?? null,
            },
          });
      }
    }

    return NextResponse.json({ ok: true });
  } catch (e) {
    console.error("sync error", e);
    return NextResponse.json({ ok: false, error: "sync failed" }, { status: 500 });
  }
}
