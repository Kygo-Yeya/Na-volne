import {
  pgTable,
  uuid,
  text,
  integer,
  boolean,
  timestamp,
  jsonb,
  uniqueIndex,
} from "drizzle-orm/pg-core";

/**
 * «На волне» — серверное хранилище.
 * Приложение офлайн-first: источник истины на клиенте (localStorage),
 * сюда данные лишь синхронизируются (тесты, чек-ины, профиль).
 */
export const users = pgTable("navolne_users", {
  id: uuid("id").defaultRandom().primaryKey(),
  anonKey: text("anon_key").notNull().unique(),
  contact: text("contact"),
  name: text("name").notNull().default("Гость"),
  isGuest: boolean("is_guest").notNull().default(true),
  premium: boolean("premium").notNull().default(false),
  premiumPlan: text("premium_plan"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const testResults = pgTable(
  "navolne_test_results",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    testVersion: text("test_version")
      .notNull()
      .default("burnout-stress-anxiety-v1.0"),
    answers: jsonb("answers").$type<number[]>().notNull(),
    scales:
      jsonb("scales").$type<
        Record<string, { raw: number; max: number; pct: number; level: string }>
      >().notNull(),
    flags: jsonb("flags").$type<Record<string, boolean>>().notNull(),
    wordResult: text("word_result").notNull(),
    symptomIndex: integer("symptom_index").notNull(),
    resilienceIndex: integer("resilience_index").notNull(),
    completedAt: text("completed_at").notNull(),
  },
  (t) => [uniqueIndex("navolne_test_user_completed").on(t.userId, t.completedAt)]
);

export const checkins = pgTable(
  "navolne_checkins",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    day: text("day").notNull(),
    mood: integer("mood").notNull(),
    note: text("note"),
    sleepHours: integer("sleep_hours"),
    energy: integer("energy"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [uniqueIndex("navolne_checkin_user_day").on(t.userId, t.day)]
);
