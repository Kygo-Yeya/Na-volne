"use client";

import React, { useEffect, useState } from "react";
import { AlertCircle, Check, ChevronLeft, Inbox, Loader2, Lock, Waves } from "lucide-react";
import { LEVEL_META, type ScaleKey, type ScaleResult, type LevelKey } from "@/lib/data";

// ───────────────────────── Бренд-знак ─────────────────────────

export function BrandMark({ size = 44, radius }: { size?: number; radius?: number }) {
  return (
    <div
      className="brand-mark"
      style={{ width: size, height: size, borderRadius: radius ?? size * 0.26 }}
      aria-hidden
    >
      <Waves size={size * 0.52} strokeWidth={2.2} />
    </div>
  );
}

// ───────────────────────── Кнопки ─────────────────────────

type BtnVariant = "primary" | "coral" | "soft" | "outline" | "ghost" | "danger" | "white";

export function Btn({
  children,
  onClick,
  variant = "primary",
  size,
  full,
  disabled,
  className,
  type,
  ariaLabel,
  style,
}: {
  children: React.ReactNode;
  onClick?: () => void;
  variant?: BtnVariant;
  size?: "lg" | "sm";
  full?: boolean;
  disabled?: boolean;
  className?: string;
  type?: "button" | "submit";
  ariaLabel?: string;
  style?: React.CSSProperties;
}) {
  const cls = [
    "btn",
    `btn-${variant}`,
    size === "lg" ? "btn-lg" : "",
    size === "sm" ? "btn-sm" : "",
    full ? "btn-full" : "",
    className ?? "",
  ]
    .join(" ")
    .trim();
  return (
    <button
      type={type ?? "button"}
      className={cls}
      onClick={onClick}
      disabled={disabled}
      aria-label={ariaLabel}
      style={style}
    >
      {children}
    </button>
  );
}

// ───────────────────────── Карточки / чипы ─────────────────────────

export function Card({
  children,
  className,
  onClick,
  pressable,
  style,
}: {
  children: React.ReactNode;
  className?: string;
  onClick?: () => void;
  pressable?: boolean;
  style?: React.CSSProperties;
}) {
  return (
    <div
      className={`card ${pressable || onClick ? "press" : ""} ${className ?? ""}`}
      onClick={onClick}
      role={onClick ? "button" : undefined}
      tabIndex={onClick ? 0 : undefined}
      style={style}
    >
      {children}
    </div>
  );
}

export function Chip({
  children,
  active,
  onClick,
}: {
  children: React.ReactNode;
  active?: boolean;
  onClick?: () => void;
}) {
  return (
    <button type="button" className={`chip ${active ? "active" : ""}`} onClick={onClick}>
      {children}
    </button>
  );
}

export function LockBadge() {
  return (
    <span className="lock-badge">
      <Lock size={11} /> Premium
    </span>
  );
}

// ───────────────────────── Навигация экрана ─────────────────────────

export function TopBar({
  title,
  onBack,
  right,
  onDark,
}: {
  title?: string;
  onBack?: () => void;
  right?: React.ReactNode;
  onDark?: boolean;
}) {
  return (
    <div className="topbar" style={onDark ? { background: "none" } : undefined}>
      {onBack && (
        <button className={`back-btn ${onDark ? "on-dark" : ""}`} onClick={onBack} aria-label="Назад">
          <ChevronLeft size={20} />
        </button>
      )}
      {title && <h2 className="h-3" style={{ color: onDark ? "#fff" : undefined }}>{title}</h2>}
      <div style={{ marginLeft: "auto" }}>{right}</div>
    </div>
  );
}

// ───────────────────────── Прогресс ─────────────────────────

export function Progress({ value }: { value: number }) {
  return (
    <div className="pbar" role="progressbar" aria-valuenow={Math.round(value)} aria-valuemin={0} aria-valuemax={100}>
      <div style={{ width: `${Math.min(100, Math.max(0, value))}%` }} />
    </div>
  );
}

export function Ring({
  value,
  size = 58,
  stroke = 5.5,
  color = "#0e7490",
  track = "rgba(13,36,48,0.08)",
  children,
}: {
  value: number;
  size?: number;
  stroke?: number;
  color?: string;
  track?: string;
  children?: React.ReactNode;
}) {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const off = c * (1 - Math.min(1, Math.max(0, value)));
  return (
    <div style={{ position: "relative", width: size, height: size, flexShrink: 0 }}>
      <svg width={size} height={size} style={{ transform: "rotate(-90deg)" }}>
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={track} strokeWidth={stroke} />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          stroke={color}
          strokeWidth={stroke}
          strokeLinecap="round"
          strokeDasharray={c}
          strokeDashoffset={off}
          style={{ transition: "stroke-dashoffset 0.5s cubic-bezier(0.2,0.8,0.2,1)" }}
        />
      </svg>
      <div style={{ position: "absolute", inset: 0, display: "grid", placeItems: "center" }}>{children}</div>
    </div>
  );
}

// ───────────────────────── Шторка / модалка ─────────────────────────

export function Sheet({
  open,
  onClose,
  children,
}: {
  open: boolean;
  onClose: () => void;
  children: React.ReactNode;
}) {
  if (!open) return null;
  return (
    <>
      <div className="scrim" onClick={onClose} />
      <div className="sheet" role="dialog" aria-modal="true">
        <div className="sheet-handle" />
        {children}
      </div>
    </>
  );
}

export function Modal({ open, children, onClose }: { open: boolean; children: React.ReactNode; onClose?: () => void }) {
  if (!open) return null;
  return (
    <div className="modal-wrap">
      <div className="scrim" onClick={onClose} style={{ zIndex: -1 }} />
      <div className="modal" role="alertdialog" aria-modal="true">
        {children}
      </div>
    </div>
  );
}

// ───────────────────────── Состояния ─────────────────────────

export function Skeleton({ h = 16, w = "100%", r = 12, mb = 10 }: { h?: number; w?: number | string; r?: number; mb?: number }) {
  return <div className="skel" style={{ height: h, width: w, borderRadius: r, marginBottom: mb }} />;
}

export function CardSkeleton({ lines = 2 }: { lines?: number }) {
  return (
    <div className="card">
      {Array.from({ length: lines }).map((_, i) => (
        <Skeleton key={i} w={i === 0 ? "55%" : "88%"} h={i === 0 ? 18 : 13} mb={10} />
      ))}
    </div>
  );
}

export function EmptyState({
  icon,
  title,
  text,
  actionLabel,
  onAction,
}: {
  icon?: React.ReactNode;
  title: string;
  text?: string;
  actionLabel?: string;
  onAction?: () => void;
}) {
  return (
    <div style={{ textAlign: "center", padding: "34px 22px" }} className="anim-in">
      <div
        style={{
          width: 66,
          height: 66,
          margin: "0 auto 14px",
          borderRadius: 22,
          display: "grid",
          placeItems: "center",
          background: "rgba(6,182,212,0.1)",
          color: "#0e7490",
        }}
      >
        {icon ?? <Inbox size={30} />}
      </div>
      <h3 className="h-3">{title}</h3>
      {text && <p className="small" style={{ marginTop: 6 }}>{text}</p>}
      {actionLabel && onAction && (
        <Btn variant="soft" size="sm" onClick={onAction} className="mt-4">
          {actionLabel}
        </Btn>
      )}
    </div>
  );
}

export function ErrorState({ onRetry, text }: { onRetry: () => void; text?: string }) {
  return (
    <div style={{ textAlign: "center", padding: "30px 22px" }} className="anim-in">
      <div
        style={{
          width: 60,
          height: 60,
          margin: "0 auto 12px",
          borderRadius: 20,
          display: "grid",
          placeItems: "center",
          background: "rgba(249,115,115,0.12)",
          color: "#e07a5f",
        }}
      >
        <AlertCircle size={28} />
      </div>
      <h3 className="h-3">Не получилось загрузить</h3>
      <p className="small" style={{ margin: "6px 0 14px" }}>{text ?? "Проверь соединение и попробуй ещё раз"}</p>
      <Btn variant="outline" size="sm" onClick={onRetry}>
        <Loader2 size={15} /> Повторить
      </Btn>
    </div>
  );
}

export function useFakeLoad(ms = 450): boolean {
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    const t = setTimeout(() => setLoading(false), ms);
    return () => clearTimeout(t);
  }, [ms]);
  return loading;
}

export function SuccessMark({ size = 84 }: { size?: number }) {
  return (
    <div
      style={{
        width: size,
        height: size,
        margin: "0 auto",
        borderRadius: "50%",
        display: "grid",
        placeItems: "center",
        background: "radial-gradient(circle at 35% 30%, #34d399, #0e9f6e)",
        color: "#fff",
        boxShadow: "0 18px 40px -14px rgba(13, 173, 117, 0.6)",
        animation: "popIn 0.45s var(--ease-out) both",
      }}
    >
      <Check size={size * 0.46} strokeWidth={3} />
    </div>
  );
}

// ───────────────────────── Радар теста (3 оси) ─────────────────────────

export function RadarTest({ scales }: { scales: Record<ScaleKey, ScaleResult> }) {
  const size = 264;
  const cx = size / 2;
  const cy = size / 2 + 4;
  const R = 88;
  const order: { key: ScaleKey; label: string }[] = [
    { key: "burnout", label: "Выгорание" },
    { key: "anxiety", label: "Тревожность" },
    { key: "stress", label: "Стресс" },
  ];
  const ang = [-90, 30, 150].map((a) => (a * Math.PI) / 180);
  const pt = (pct: number, i: number): [number, number] => [
    cx + Math.cos(ang[i]) * R * (pct / 100),
    cy + Math.sin(ang[i]) * R * (pct / 100),
  ];
  const ring = (r: number) =>
    ang.map((a) => `${cx + Math.cos(a) * R * r},${cy + Math.sin(a) * R * r}`).join(" ");
  const poly = order.map((o, i) => pt(Math.max(scales[o.key].pct, 2), i).join(",")).join(" ");

  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} role="img" aria-label="Диаграмма состояния">
      {[1, 0.75, 0.5, 0.25].map((r) => (
        <polygon key={r} points={ring(r)} fill="none" stroke="rgba(13,36,48,0.09)" strokeWidth="1" />
      ))}
      {ang.map((a, i) => (
        <line
          key={i}
          x1={cx}
          y1={cy}
          x2={cx + Math.cos(a) * R}
          y2={cy + Math.sin(a) * R}
          stroke="rgba(13,36,48,0.09)"
          strokeWidth="1"
        />
      ))}
      <polygon
        className="radar-poly"
        points={poly}
        fill="rgba(6,182,212,0.18)"
        stroke="#0e7490"
        strokeWidth="2"
        strokeLinejoin="round"
      />
      {order.map((o, i) => {
        const s = scales[o.key];
        const meta = LEVEL_META[s.level];
        const [x, y] = pt(Math.max(s.pct, 2), i);
        const [lx, ly] = pt(128, i);
        return (
          <g key={o.key}>
            <circle cx={x} cy={y} r="5.5" fill={meta.color} stroke="#fff" strokeWidth="2" />
            <text
              x={lx}
              y={ly}
              textAnchor={i === 0 ? "middle" : i === 1 ? "start" : "end"}
              fontSize="11.5"
              fontWeight="700"
              fill="#0d2430"
              dy={i === 0 ? -2 : 4}
            >
              {o.label}
            </text>
            <text
              x={lx}
              y={ly}
              dy={i === 0 ? 12 : 18}
              textAnchor={i === 0 ? "middle" : i === 1 ? "start" : "end"}
              fontSize="11.5"
              fontWeight="800"
              fill={meta.color}
            >
              {s.pct}%
            </text>
          </g>
        );
      })}
      <circle cx={cx} cy={cy} r="3" fill="rgba(13,36,48,0.25)" />
    </svg>
  );
}

// ───────────────────────── Легенда уровней ─────────────────────────

export function LevelLegend({ scales }: { scales: Record<ScaleKey, ScaleResult> }) {
  const order: ScaleKey[] = ["burnout", "anxiety", "stress"];
  return (
    <div className="row" style={{ justifyContent: "center", gap: 8, flexWrap: "wrap" }}>
      {order.map((k) => {
        const s = scales[k];
        const meta = LEVEL_META[s.level];
        return (
          <span
            key={k}
            className="chip"
            style={{ cursor: "default", background: meta.soft, borderColor: "transparent", color: meta.color, minHeight: 30, fontSize: 12 }}
          >
            {meta.label}
          </span>
        );
      })}
    </div>
  );
}

// ───────────────────────── Спарклайн настроения ─────────────────────────

export function Spark({ values, height = 54, width = 300 }: { values: (number | null)[]; height?: number; width?: number }) {
  const pts = values.map((v, i) => ({ i, v }));
  const valid = pts.filter((p) => p.v != null) as { i: number; v: number }[];
  const w = width;
  const h = height;
  const pad = 14;
  const x = (i: number) => pad + (i * (w - pad * 2)) / (values.length - 1 || 1);
  const y = (v: number) => h - pad - ((v - 1) * (h - pad * 2)) / 4;
  if (valid.length === 0)
    return (
      <svg width={w} height={h} aria-hidden>
        <line x1={pad} x2={w - pad} y1={h / 2} y2={h / 2} stroke="rgba(13,36,48,0.1)" strokeDasharray="4 6" />
      </svg>
    );
  const path = valid.map((p, idx) => `${idx === 0 ? "M" : "L"}${x(p.i)},${y(p.v)}`).join(" ");
  const area = `${path} L${x(valid[valid.length - 1].i)},${h - 2} L${x(valid[0].i)},${h - 2} Z`;
  return (
    <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`} style={{ display: "block", width: "100%", height: "auto" }} aria-hidden>
      <defs>
        <linearGradient id="sparkG" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#06b6d4" stopOpacity="0.28" />
          <stop offset="100%" stopColor="#06b6d4" stopOpacity="0.02" />
        </linearGradient>
      </defs>
      {valid.length > 1 && (
        <>
          <path d={area} fill="url(#sparkG)" />
          <path d={path} fill="none" stroke="#0e7490" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" />
        </>
      )}
      {valid.map((p) => (
        <circle key={p.i} cx={x(p.i)} cy={y(p.v)} r="4" fill="#fff" stroke="#0e7490" strokeWidth="2.4" />
      ))}
    </svg>
  );
}

// ───────────────────────── Радар карты личности (5 зон) ─────────────────────────

export function RadarPenta({ axes }: { axes: { label: string; pct: number }[] }) {
  const size = 280;
  const cx = size / 2;
  const cy = size / 2 + 6;
  const R = 84;
  const n = axes.length;
  const angle = (i: number) => -Math.PI / 2 + (i * 2 * Math.PI) / n;
  const pt = (pct: number, i: number): [number, number] => [
    cx + Math.cos(angle(i)) * R * (pct / 100),
    cy + Math.sin(angle(i)) * R * (pct / 100),
  ];
  const ringPts = (r: number) =>
    axes.map((_, i) => `${cx + Math.cos(angle(i)) * R * r},${cy + Math.sin(angle(i)) * R * r}`).join(" ");
  const poly = axes.map((a, i) => pt(Math.max(a.pct, 3), i).join(",")).join(" ");
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} style={{ display: "block", margin: "0 auto" }} role="img" aria-label="Карта личности">
      {[1, 0.75, 0.5, 0.25].map((r) => (
        <polygon key={r} points={ringPts(r)} fill={r === 1 ? "rgba(6,182,212,0.04)" : "none"} stroke="rgba(13,36,48,0.09)" strokeWidth="1" />
      ))}
      {axes.map((_, i) => (
        <line key={i} x1={cx} y1={cy} x2={cx + Math.cos(angle(i)) * R} y2={cy + Math.sin(angle(i)) * R} stroke="rgba(13,36,48,0.08)" />
      ))}
      <polygon className="radar-poly" points={poly} fill="rgba(6,182,212,0.22)" stroke="#0e7490" strokeWidth="2.2" strokeLinejoin="round" />
      {axes.map((a, i) => {
        const [x, y] = pt(Math.max(a.pct, 3), i);
        const lx = cx + Math.cos(angle(i)) * (R + 34);
        const ly = cy + Math.sin(angle(i)) * (R + 30);
        const anchor = Math.abs(Math.cos(angle(i))) < 0.4 ? "middle" : Math.cos(angle(i)) > 0 ? "start" : "end";
        return (
          <g key={a.label}>
            <circle cx={x} cy={y} r="5" fill="#06b6d4" stroke="#fff" strokeWidth="2" />
            <text x={lx} y={ly} textAnchor={anchor} fontSize="11" fontWeight="650" fill="#0d2430">
              {a.label}
            </text>
            <text x={lx} y={ly + 13} textAnchor={anchor} fontSize="11" fontWeight="800" fill="#0e7490">
              {a.pct}%
            </text>
          </g>
        );
      })}
    </svg>
  );
}

export function levelTone(level: LevelKey): string {
  return LEVEL_META[level].color;
}
