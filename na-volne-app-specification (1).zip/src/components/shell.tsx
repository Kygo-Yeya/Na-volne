"use client";

import React, { useEffect, useState } from "react";
import {
  Check,
  CircleUserRound,
  Compass,
  House,
  LifeBuoy,
  Sparkles,
  Users,
  Waves,
} from "lucide-react";
import { AppProvider, useApp, type AppRoute, type Entry, type TabId } from "@/lib/store";
import { Splash, Onboarding, Auth, Verify } from "@/screens/intro";
import { TestCover, TestQuestion, TestResult, Plan } from "@/screens/test";
import { Today, CheckInSheet, SleepScreen } from "@/screens/home";
import {
  Tools,
  MapScreen,
  Courses,
  CourseScreen,
  LessonScreen,
  Techniques,
  TechniqueScreen,
  Soundscapes,
  Player,
  Body,
} from "@/screens/tools";
import { SosMenu, SosBreathe, SosDialog, SosGrounding } from "@/screens/sos";
import { Diary } from "@/screens/diary";
import { Profile, Settings, Paywall, Community } from "@/screens/account";

// ───────────────────────── Амбиентный фон (десктоп) ─────────────────────────

function Ambient() {
  return (
    <>
      <div className="ambient" aria-hidden>
        <div className="blob blob-a" />
        <div className="blob blob-b" />
        <div className="blob blob-c" />
      </div>
      <div className="wavefield" aria-hidden>
        {[0, 60, 120].map((offset, layer) => (
          <svg key={layer} viewBox="0 0 1600 220" preserveAspectRatio="none" className={`wave-${layer + 1}`}>
            <path
              d={`M0 ${110 + layer * 22} C 200 ${70 + offset / 2}, 300 ${150}, 500 ${118} S 800 ${60}, 1000 ${110 + layer * 14} S 1400 ${90}, 1600 ${120} L1600 220 L0 220 Z`}
              fill={layer === 2 ? "rgba(224,122,95,0.25)" : "rgba(103,232,249,0.4)"}
            />
            <path
              d={`M800 ${110 + layer * 22} C 1000 ${70 + offset / 2}, 1100 ${150}, 1300 ${118} S 1600 ${60}, 1800 ${110 + layer * 14} S 2200 ${90}, 2400 ${120} L2400 220 L1600 220 Z`}
              fill={layer === 2 ? "rgba(224,122,95,0.25)" : "rgba(103,232,249,0.4)"}
            />
          </svg>
        ))}
      </div>
    </>
  );
}

function SideCaption() {
  return (
    <div className="side">
      <span className="side-brand">
        <Waves size={16} /> НА ВОЛНЕ
      </span>
      <h1>
        Персональный план <em>психологической устойчивости</em>
      </h1>
      <p>
        Интерактивный макет мобильного приложения: пройди онбординг и научный тест, собери план на 21 день и попробуй
        SOS-режим — всё кликабельно.
      </p>
      <ul className="side-feats">
        <li>
          <Sparkles size={16} /> Тест «выгорание • стресс • тревожность» — 14 вопросов, ~2 минуты
        </li>
        <li>
          <LifeBuoy size={16} /> SOS: дыхание 4-7-8, заземление и бережный диалог
        </li>
        <li>
          <Compass size={16} /> Карта личности, курсы, техники и саундскейпы
        </li>
      </ul>
      <span className="side-tag">Интерактивный макет • 375 × 812 • работает офлайн</span>
      <p className="side-foot">
        Тест не является медицинским диагнозом. Данные макета хранятся локально (localStorage, ключи navolne_*).
      </p>
    </div>
  );
}

// ───────────────────────── Статус-бар ─────────────────────────

function StatusBar({ light }: { light: boolean }) {
  const [time, setTime] = useState("09:41");
  useEffect(() => {
    const upd = () =>
      setTime(new Intl.DateTimeFormat("ru-RU", { hour: "2-digit", minute: "2-digit" }).format(new Date()));
    upd();
    const id = setInterval(upd, 10_000);
    return () => clearInterval(id);
  }, []);

  return (
    <div className={`statusbar ${light ? "light" : "dark"}`}>
      <span style={{ fontVariantNumeric: "tabular-nums" }}>{time}</span>
      <span className="sb-icons">
        <svg width="17" height="12" viewBox="0 0 17 12" fill="currentColor" aria-hidden>
          <rect x="0" y="7" width="3" height="5" rx="1" />
          <rect x="4.5" y="5" width="3" height="7" rx="1" />
          <rect x="9" y="2.5" width="3" height="9.5" rx="1" />
          <rect x="13.5" y="0" width="3" height="12" rx="1" opacity="0.45" />
        </svg>
        <svg width="16" height="12" viewBox="0 0 16 12" fill="currentColor" aria-hidden>
          <path d="M8 9.6a1.4 1.4 0 1 1 0 2.8 1.4 1.4 0 0 1 0-2.8ZM8 5.6c1.9 0 3.6.78 4.85 2.02l-1.6 1.6A4.4 4.4 0 0 0 8 7.2c-1.25 0-2.38.53-3.17 1.37l-1.6-1.6A6.6 6.6 0 0 1 8 5.6Z" opacity="0.95"/>
          <path d="M8 1.6c2.9 0 5.55 1.17 7.46 3.07l-1.6 1.6A8.6 8.6 0 0 0 8 3.2 8.6 8.6 0 0 0 2.14 6.27l-1.6-1.6A10.6 10.6 0 0 1 8 1.6Z" opacity="0.95"/>
        </svg>
        <svg width="25" height="12" viewBox="0 0 25 12" aria-hidden>
          <rect x="0.5" y="0.5" width="21" height="11" rx="3.5" fill="none" stroke="currentColor" opacity="0.5" />
          <rect x="2" y="2" width="15" height="8" rx="2" fill="currentColor" />
          <path d="M23 4v4a2 2 0 0 0 0-4Z" fill="currentColor" opacity="0.5" />
        </svg>
      </span>
    </div>
  );
}

// ───────────────────────── Таб-бар ─────────────────────────

const TABS: { id: TabId; label: string; icon: React.ElementType }[] = [
  { id: "today", label: "Сегодня", icon: House },
  { id: "tools", label: "Инструменты", icon: Compass },
  { id: "community", label: "Сообщество", icon: Users },
  { id: "profile", label: "Профиль", icon: CircleUserRound },
];

function TabBar() {
  const { tab, goTab, openSos } = useApp();
  return (
    <nav className="tabbar" aria-label="Основная навигация">
      {[TABS[0], TABS[1]].map((t) => (
        <button key={t.id} className={`tab-item ${tab === t.id ? "active" : ""}`} onClick={() => goTab(t.id)}>
          <t.icon size={22} strokeWidth={tab === t.id ? 2.4 : 1.9} />
          {t.label}
        </button>
      ))}

      <div style={{ flex: 1, display: "flex", justifyContent: "center" }}>
        <button className="sos-fab" onClick={openSos} aria-label="SOS — быстрая помощь">
          <LifeBuoy size={26} />
        </button>
      </div>
      <div style={{ position: "absolute", bottom: 6, left: "50%", transform: "translateX(-50%)" }}>
        <span className="sos-label">SOS</span>
      </div>

      {[TABS[2], TABS[3]].map((t) => (
        <button key={t.id} className={`tab-item ${tab === t.id ? "active" : ""}`} onClick={() => goTab(t.id)}>
          <t.icon size={22} strokeWidth={tab === t.id ? 2.4 : 1.9} />
          {t.label}
        </button>
      ))}
    </nav>
  );
}

// ───────────────────────── Тосты ─────────────────────────

function Toasts() {
  const { toasts } = useApp();
  return (
    <div className="toasts" aria-live="polite">
      {toasts.map((t) => (
        <div key={t.id} className="toast">
          <span className="t-ic">
            <Check size={14} strokeWidth={3} />
          </span>
          {t.msg}
        </div>
      ))}
    </div>
  );
}

// ───────────────────────── Роутеры ─────────────────────────

function renderAppRoute(e: Entry<AppRoute>) {
  switch (e.route) {
    case "today": return <Today />;
    case "tools": return <Tools />;
    case "map": return <MapScreen />;
    case "courses": return <Courses />;
    case "course": return <CourseScreen />;
    case "lesson": return <LessonScreen />;
    case "techniques": return <Techniques />;
    case "technique": return <TechniqueScreen />;
    case "soundscapes": return <Soundscapes />;
    case "player": return <Player />;
    case "body": return <Body />;
    case "diary": return <Diary />;
    case "sleep": return <SleepScreen />;
    case "community": return <Community />;
    case "profile": return <Profile />;
    case "settings": return <Settings />;
    default: return <Today />;
  }
}

function FlowRouter() {
  const { flowCurrent } = useApp();
  const key = `${flowCurrent.route}-${JSON.stringify(flowCurrent.params ?? {})}`;
  return (
    <div key={key} style={{ position: "absolute", inset: 0 }}>
      {flowCurrent.route === "splash" && <Splash />}
      {flowCurrent.route === "onboarding" && <Onboarding />}
      {flowCurrent.route === "auth" && <Auth />}
      {flowCurrent.route === "verify" && <Verify />}
      {flowCurrent.route === "testCover" && <TestCover />}
      {flowCurrent.route === "testQ" && <TestQuestion />}
      {flowCurrent.route === "testResult" && <TestResult />}
      {flowCurrent.route === "plan" && <Plan />}
    </div>
  );
}

function TabStacks() {
  const { tab, stacks } = useApp();
  // Все вкладки остаются смонтированными (скрыты через display:none) —
  // так сохраняются прокрутка и состояние форм при переключении.
  return (
    <>
      {(["today", "tools", "community", "profile"] as TabId[]).map((t) => {
        const entry = stacks[t][stacks[t].length - 1];
        const key = `${t}-${entry.route}-${JSON.stringify(entry.params ?? {})}`;
        return (
          <div key={t} style={{ display: t === tab ? "block" : "none", position: "absolute", inset: 0 }}>
            <div key={key} className="anim-in" style={{ position: "absolute", inset: 0 }}>
              {renderAppRoute(entry)}
            </div>
          </div>
        );
      })}
    </>
  );
}

function SosOverlay() {
  const { sos, sosCurrent } = useApp();
  if (!sos || !sosCurrent) return null;
  const key = sosCurrent.route;
  return (
    <div className="overlay-page" style={{ zIndex: 88, background: "#0c1d2b" }}>
      <div key={key} style={{ position: "absolute", inset: 0 }}>
        {sosCurrent.route === "sos" && <SosMenu />}
        {sosCurrent.route === "sosBreathe" && <SosBreathe />}
        {sosCurrent.route === "sosDialog" && <SosDialog />}
        {sosCurrent.route === "sosGrounding" && <SosGrounding />}
      </div>
    </div>
  );
}

// ───────────────────────── Телефон ─────────────────────────

function Phone() {
  const { hydrated, state, sos, flowCurrent, current, checkinOpen } = useApp();

  const lightBar =
    !hydrated ||
    Boolean(sos) ||
    (!state.onboarded && flowCurrent.route === "splash") ||
    (state.onboarded && current.route === "player");

  return (
    <div className="phone">
      <div className="screen-frame">
        <div className="island" />
        <StatusBar light={lightBar} />
        <div className="viewport">
          {!hydrated ? (
            <Splash />
          ) : !state.onboarded ? (
            <FlowRouter />
          ) : (
            <>
              <TabStacks />
              <TabBar />
            </>
          )}
          <SosOverlay />
          {checkinOpen && <CheckInSheet />}
          <Paywall />
          <Toasts />
        </div>
      </div>
    </div>
  );
}

export default function AppShell() {
  return (
    <AppProvider>
      <div className="stage">
        <Ambient />
        <SideCaption />
        <Phone />
        <div className="grain" aria-hidden />
      </div>
    </AppProvider>
  );
}
